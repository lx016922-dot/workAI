$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$base=$PSScriptRoot
$state=[IO.File]::ReadAllText((Join-Path $base 'run-status.json'),[Text.Encoding]::UTF8)|ConvertFrom-Json
$result=[ordered]@{observed_utc=[DateTime]::UtcNow.ToString('o');status=$state}
if($state.native_pid){
    $native=Get-Process -Id ([int]$state.native_pid) -ErrorAction SilentlyContinue
    if($null -ne $native){$result['native']=[ordered]@{pid=[int]$native.Id;name=[string]$native.Name;cpu_seconds=[double]$native.CPU;memory_mb=[Math]::Round([double]$native.WorkingSet64/1MB,1)}}
}
if($state.log_file -and [IO.File]::Exists($state.log_file)){
    $stream=[IO.File]::Open($state.log_file,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    try {
        $length=$stream.Length;$count=[int][Math]::Min(131072,$length);$offset=$length-$count;$stream.Position=$offset
        $buffer=New-Object byte[] $count;$read=0
        while($read -lt $count){$n=$stream.Read($buffer,$read,$count-$read);if($n -le 0){break};$read+=$n}
    } finally {$stream.Dispose()}
    $lines=[Text.Encoding]::UTF8.GetString($buffer,0,$read) -split '\r?\n'
    if($offset -gt 0){$lines=@($lines|Select-Object -Skip 1)}
    $result['log_bytes']=$length
    $result['log_tail']=@($lines|Select-Object -Last 10)
    $result['time_steps']=@($lines|Where-Object {$_ -match '^\s*\d+\s+[-+.0-9Ee]+\s+'}|Select-Object -Last 4)
}
$gate=Join-Path $base 'preflight-passed.json'
if(Test-Path -LiteralPath $gate){$result['preflight']=Get-Content -LiteralPath $gate -Raw -Encoding UTF8|ConvertFrom-Json}
$result|ConvertTo-Json -Depth 12 -Compress

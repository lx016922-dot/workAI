param([ValidateRange(1,36)][int]$Cores=18)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$base=$PSScriptRoot
$taskName='Codex_P1_SERP_20261102'
$bin='D:\COMSOL64\Multiphysics\bin\win64'
if(-not(Test-Path -LiteralPath (Join-Path $bin 'comsolbatch.exe'))){throw 'COMSOL 6.4 not found'}
if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'Revision task already exists; inspect before restart'}
$tokens=$null;$errors=$null
[Management.Automation.Language.Parser]::ParseFile((Join-Path $base 'run-gated.ps1'),[ref]$tokens,[ref]$errors)|Out-Null
if($errors.Count){throw ($errors.Message -join '; ')}
$taskArguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+(Join-Path $base 'run-gated.ps1')+'" -Cores '+$Cores
$action=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $taskArguments -WorkingDirectory $base
$principal=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings -Description 'P1 serendipity: material check and six DOF checks must pass before six tier-1 transient jobs. No recurring trigger.'|Out-Null
Start-ScheduledTask -TaskName $taskName
[ordered]@{task_name=$taskName;task_state=(Get-ScheduledTask -TaskName $taskName).State.ToString();cores=$Cores;root=$base}|ConvertTo-Json -Compress

param(
    [string]$ComsolBin='D:\COMSOL64\Multiphysics\bin\win64',
    [ValidateRange(1,36)][int]$Cores=18
)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$base=$PSScriptRoot
$utf8=New-Object Text.UTF8Encoding($false)
$statusPath=Join-Path $base 'run-status.json'
$state=[ordered]@{schema='p1.serendipity.run.v1';state='verifying_inputs';controller_pid=$PID;started_utc=[DateTime]::UtcNow.ToString('o');updated_utc=$null;comsol_bin=$ComsolBin;cores_per_job=$Cores;tiers=@(0,1);source_sha256=$null;current_job=$null;current_directory=$null;log_file=$null;native_pid=$null;completed_jobs=@();mesh_checks_passed=@();preflight_passed=$false;error=$null}
function Save-State {
    $state.updated_utc=[DateTime]::UtcNow.ToString('o')
    $temporary=Join-Path $base ('run-status.'+$PID+'.tmp')
    [IO.File]::WriteAllText($temporary,($state|ConvertTo-Json -Depth 9),$utf8)
    Move-Item -LiteralPath $temporary -Destination $statusPath -Force
}
function Read-Json([string]$Filename){ Get-Content -LiteralPath $Filename -Raw -Encoding UTF8|ConvertFrom-Json }
function Read-Properties([string]$Filename){ Get-Content -LiteralPath $Filename -Raw -Encoding UTF8|ConvertFrom-StringData }
function Write-Json([string]$Filename,$Value){ [IO.File]::WriteAllText($Filename,($Value|ConvertTo-Json -Depth 12),$utf8) }
function Invoke-Native([string]$Executable,[string[]]$NativeArguments,[string]$Directory,[string]$Label){
    $proc=Start-Process -FilePath $Executable -ArgumentList $NativeArguments -WorkingDirectory $Directory -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $Directory ($Label+'.stdout.log')) -RedirectStandardError (Join-Path $Directory ($Label+'.stderr.log'))
    $nativeHandle=$proc.Handle
    $state.native_pid=$proc.Id
    Save-State
    while(-not $proc.WaitForExit(15000)){Save-State}
    $proc.WaitForExit()
    $exitCode=$proc.ExitCode
    $state.native_pid=$null
    Save-State
    if($exitCode -ne 0){throw "$Label returned $exitCode in $Directory"}
}
function Check-Input([string]$Directory){
    $identity=Read-Json (Join-Path $Directory 'identity.json')
    $sourceHash=(Get-FileHash -LiteralPath (Join-Path $Directory 'UltraResearch.java') -Algorithm SHA256).Hash.ToLowerInvariant()
    if($sourceHash -ne $manifest.source_sha256 -or $identity.source_sha256 -ne $sourceHash){throw "Source hash mismatch: $Directory"}
    $request=Read-Json (Join-Path $Directory 'request.json')
    $properties=Read-Properties (Join-Path $Directory 'case.properties')
    foreach($key in @('job_id','source_sha256','scene_sha256','parameters_sha256')){
        if($identity.$key -ne $request.$key -or $identity.$key -ne $properties[$key]){throw "Identity mismatch: $Directory / $key"}
    }
    $digest=[Security.Cryptography.SHA256]::Create()
    try {
        foreach($pair in @(@('scene_json','scene_sha256'),@('parameters_json','parameters_sha256'))){
            $actual=([BitConverter]::ToString($digest.ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$request.($pair[0]))))).Replace('-','').ToLowerInvariant()
            if($actual -ne $identity.($pair[1])){throw "Canonical input hash mismatch: $Directory"}
        }
    } finally { $digest.Dispose() }
    return $identity
}
function Check-Receipt([string]$Filename,$Identity,[string]$ExpectedStatus){
    if(-not (Test-Path -LiteralPath $Filename)){throw "Receipt missing: $Filename"}
    $receipt=Read-Properties $Filename
    if($receipt.status -ne $ExpectedStatus){throw "Receipt status mismatch: $Filename"}
    foreach($key in @('job_id','source_sha256','scene_sha256','parameters_sha256')){
        if($receipt[$key] -ne $Identity.$key){throw "Receipt identity mismatch: $Filename / $key"}
    }
    return $receipt
}
function Compile-Production([string]$Directory){
    Invoke-Native (Join-Path $ComsolBin 'comsolcompile.exe') @('UltraResearch.java') $Directory 'compile'
    if(-not (Test-Path -LiteralPath (Join-Path $Directory 'UltraResearch.class'))){throw "Missing compiled model: $Directory"}
}
function Run-Model([string]$Directory,[string]$InputClass,[string]$LogName){
    $state.log_file=Join-Path $Directory $LogName
    Save-State
    $arguments=@('-np',[string]$Cores,'-prefsdir',$prefsDirectory,'-migrateprefs','off','-classpathadd',$Directory,'-inputfile',$InputClass,'-batchlog',$LogName)
    Invoke-Native (Join-Path $ComsolBin 'comsolbatch.exe') $arguments $Directory 'batch'
}
$lock=$null
try {
    $lock=[IO.File]::Open((Join-Path $base 'controller.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $manifest=Read-Json (Join-Path $base 'revision-manifest.json')
    $state.source_sha256=$manifest.source_sha256
    Save-State
    foreach($item in $manifest.all_input_files){
        $hash=(Get-FileHash -LiteralPath (Join-Path $base $item.path) -Algorithm SHA256).Hash.ToLowerInvariant()
        if($hash -ne $item.sha256){throw "Packaged file changed: $($item.path)"}
    }
    $prefsDirectory=Join-Path $base 'runtime\prefs'
    New-Item -ItemType Directory -Path $prefsDirectory -Force|Out-Null
    [IO.File]::WriteAllText((Join-Path $prefsDirectory 'comsol.prefs'),"security.external.filepermission=full`n",$utf8)
    $state['prefs_directory']=$prefsDirectory
    foreach($name in @('comsolcompile.exe','comsolbatch.exe')){
        if(-not (Test-Path -LiteralPath (Join-Path $ComsolBin $name))){throw "COMSOL executable missing: $name"}
    }
    $jobs=Read-Json (Join-Path $base 'p1-kit\jobs.json')
    $material=@($jobs|Where-Object {[int]$_.tier -eq 0})
    if($material.Count -ne 1){throw 'Expected one material check'}
    $job=$material[0]
    $directory=Join-Path (Join-Path $base 'p1-kit\runs') $job.folder
    $identity=Check-Input $directory
    $state.current_job=$job.folder
    $state.current_directory=$directory
    $state.state='constitutive_check'
    Save-State
    $receiptFile=Join-Path $directory 'completed.properties'
    if(-not (Test-Path -LiteralPath $receiptFile)){
        Compile-Production $directory
        Run-Model $directory 'UltraResearch.class' 'solver.log'
    }
    $receipt=Check-Receipt $receiptFile $identity 'completed'
    $rows=Import-Csv -LiteralPath (Join-Path $directory 'coarse.csv') -Encoding UTF8
    $maxError=0.0
    foreach($row in $rows){
        $value=[double]::Parse($row.S_MPa,[Globalization.CultureInfo]::InvariantCulture)
        $expected=[double]::Parse($row.S_expected_MPa,[Globalization.CultureInfo]::InvariantCulture)
        if([double]::IsNaN($value) -or [double]::IsInfinity($value)){throw 'Nonfinite material-check stress'}
        $maxError=[Math]::Max($maxError,[Math]::Abs($value-$expected))
    }
    if($rows.Count -ne 27 -or $maxError -gt 1e-5 -or [int]$receipt.dofs -ne 150 -or [int]$receipt.volume_hexahedra -ne 1){throw 'Material check failed'}
    $selfResult=[ordered]@{status='passed';source_sha256=$manifest.source_sha256;job_id=$identity.job_id;stress_rows=$rows.Count;max_abs_stress_error_MPa=$maxError;limit_MPa=1e-5;dofs=[int]$receipt.dofs;volume_hexahedra=[int]$receipt.volume_hexahedra;completed_at_utc=$receipt.completed_at_utc}
    Write-Json (Join-Path $base 'selfcheck-validation.json') $selfResult
    $state.completed_jobs+= $job.folder
    Save-State
    $meshJobs=Read-Json (Join-Path $base 'preflight-jobs.json')
    if($meshJobs.Count -ne 6){throw 'Expected six baseline mesh checks'}
    $meshResults=@()
    foreach($meshJob in $meshJobs){
        $directory=Join-Path (Join-Path $base 'validation') $meshJob.folder
        $identity=Check-Input $directory
        $state.current_job=$meshJob.folder
        $state.current_directory=$directory
        $state.state='mesh_check'
        $state.log_file=Join-Path $directory 'mesh.log'
        Save-State
        $checkFile=Join-Path $directory 'mesh-check.properties'
        if(-not (Test-Path -LiteralPath $checkFile)){
            Compile-Production $directory
            Invoke-Native (Join-Path $ComsolBin 'comsolcompile.exe') @('-classpathadd',$directory,'P1DofCheck.java') $directory 'compile-helper'
            if(-not (Test-Path -LiteralPath (Join-Path $directory 'P1DofCheck.class'))){throw 'Mesh helper compilation failed'}
            Run-Model $directory 'P1DofCheck.class' 'mesh.log'
        }
        $check=Check-Receipt $checkFile $identity 'passed'
        if($check.shape_function -ne 'shnserp' -or [int]$check.degree -ne 4 -or [int]$check.dofs -ne [int]$meshJob.expected_dofs -or [int]$check.volume_hexahedra -ne [int]$meshJob.expected_volume_hexahedra){throw "Documented mesh mismatch: $($meshJob.folder)"}
        $meshResults+=[pscustomobject]@{job=$meshJob.folder;job_id=$identity.job_id;source_sha256=$check.source_sha256;shape_function=$check.shape_function;degree=[int]$check.degree;dofs=[int]$check.dofs;expected_dofs=[int]$meshJob.expected_dofs;volume_hexahedra=[int]$check.volume_hexahedra;field_names=$check.field_names;field_dofs=$check.field_dofs;checked_at_utc=$check.checked_at_utc;status='passed'}
        $state.mesh_checks_passed+=$meshJob.folder
        Save-State
    }
    if($meshResults.Count -ne 6){throw 'Incomplete mesh preflight'}
    $gate=[ordered]@{schema='p1.serendipity.preflight.v1';status='passed';passed_at_utc=[DateTime]::UtcNow.ToString('o');source_sha256=$manifest.source_sha256;selfcheck=$selfResult;meshes=$meshResults;selected_tiers=@(0,1)}
    Write-Json (Join-Path $base 'preflight-passed.json') $gate
    $state.preflight_passed=$true
    Save-State
    foreach($job in @($jobs|Where-Object {[int]$_.tier -eq 1})){
        $directory=Join-Path (Join-Path $base 'p1-kit\runs') $job.folder
        $identity=Check-Input $directory
        $state.current_job=$job.folder
        $state.current_directory=$directory
        $state.log_file=Join-Path $directory 'solver.log'
        $receiptFile=Join-Path $directory 'completed.properties'
        if(-not (Test-Path -LiteralPath $receiptFile)){
            $state.state='compiling'
            Save-State
            Compile-Production $directory
            $state.state='solving'
            Save-State
            Run-Model $directory 'UltraResearch.class' 'solver.log'
        }
        $receipt=Check-Receipt $receiptFile $identity 'completed'
        $expectedDofs=if($job.case_id -like 'C-*'){30711}else{22167}
        if([int]$receipt.dofs -ne $expectedDofs){throw "Production DOF count changed: $($job.folder)"}
        $state.completed_jobs+=$job.folder
        Save-State
    }
    $state.state='completed'
    $state.current_job=$null
    $state.current_directory=$null
    Save-State
} catch {
    if($null -ne $lock){
        $state.state='failed'
        $state.error=$_.Exception.Message
        $state['error_line']=$_.InvocationInfo.PositionMessage
        $state['error_stack']=$_.ScriptStackTrace
        Save-State
    }
    throw
} finally {
    if($null -ne $lock){$lock.Dispose()}
}

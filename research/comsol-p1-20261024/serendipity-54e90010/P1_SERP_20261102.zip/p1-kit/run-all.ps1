﻿# Runs every job folder under runs\ in order, skipping finished ones. Usage (PowerShell):
#   .\run-all.ps1 -ComsolBin "C:\Program Files\COMSOL\COMSOL64\Multiphysics\bin\win64" [-Tier 0,1] [-Cores 8]
param([Parameter(Mandatory=$true)][string]$ComsolBin, [int[]]$Tier, [int]$Cores = 0)
$ErrorActionPreference = 'Stop'
$jobs = Get-Content (Join-Path $PSScriptRoot 'jobs.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($job in $jobs) {
  if ($Tier -and -not ($Tier -contains [int]$job.tier)) { continue }
  $dir = Join-Path (Join-Path $PSScriptRoot 'runs') $job.folder
  if (Test-Path (Join-Path $dir 'completed.properties')) { Write-Host "done    $($job.folder)"; continue }
  Write-Host "running $($job.folder)  ($($job.purpose))"
  Push-Location $dir
  try {
    & (Join-Path $ComsolBin 'comsolcompile.exe') 'UltraResearch.java' *> 'compile.log'
    if (-not (Test-Path 'UltraResearch.class')) { throw "compile failed, see $dir\compile.log" }
    $extra = @(); if ($Cores -gt 0) { $extra = @('-np', "$Cores") }
    & (Join-Path $ComsolBin 'comsolbatch.exe') @extra -inputfile 'UltraResearch.class' -batchlog 'solver.log'
    if (-not (Test-Path 'completed.properties')) { throw "job did not complete, see $dir\solver.log" }
  } finally { Pop-Location }
}

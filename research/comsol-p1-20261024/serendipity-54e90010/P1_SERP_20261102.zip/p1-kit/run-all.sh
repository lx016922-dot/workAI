#!/bin/sh
# Runs every job folder under runs/ in order, skipping finished ones.
#   COMSOL_BIN=/usr/local/comsol64/multiphysics/bin sh run-all.sh [tier ...]
set -e
here=$(cd "$(dirname "$0")" && pwd)
: "${COMSOL_BIN:?set COMSOL_BIN to the COMSOL bin directory}"
for dir in "$here"/runs/*/; do
  name=$(basename "$dir")
  tier=$(python3 -c "import json,sys;print(next(j['tier'] for j in json.load(open('$here/jobs.json')) if j['folder']=='$name'))")
  if [ $# -gt 0 ] && ! echo " $* " | grep -q " $tier "; then continue; fi
  if [ -f "$dir/completed.properties" ]; then echo "done    $name"; continue; fi
  echo "running $name"
  (cd "$dir" && "$COMSOL_BIN/comsol" compile UltraResearch.java > compile.log 2>&1 \
     && "$COMSOL_BIN/comsol" batch -inputfile UltraResearch.class -batchlog solver.log)
  [ -f "$dir/completed.properties" ] || { echo "job $name did not complete; see $dir/solver.log"; exit 1; }
done

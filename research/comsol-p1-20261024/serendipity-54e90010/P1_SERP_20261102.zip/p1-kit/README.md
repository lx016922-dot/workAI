# P1 quartic serendipity revision

Source SHA-256: `54e90010ad0c63181afd7d0ff32348afa7a6b02f49f96cf77fcef48996548344`.

The original archive is preserved separately. This revision replaces shlag with shnserp at order 4 and adds a mesh-only diagnostic entry point. All 22 job identities and source hashes are updated. Physical input hashes are unchanged. Run the gated controller provided with this revision; it checks material response and all six baseline meshes before transient runs.

Original README retained below for provenance (its original source hash is superseded by the hash above).

# P1 剩余 COMSOL 运行包

每个 `runs/` 子文件夹是一个独立作业，包含已归档的模型源码 `UltraResearch.java`（SHA-256 `c7140d6c…`，本构自检就是用它通过的），以及按哈希锁定的输入。模型完全由源码和输入决定，不需要在图形界面里建模。

## 运行

Windows（PowerShell）：

```powershell
.\run-all.ps1 -ComsolBin "C:\Program Files\COMSOL\COMSOL64\Multiphysics\bin\win64" -Tier 0,1
```

Linux：

```sh
COMSOL_BIN=/usr/local/comsol64/multiphysics/bin sh run-all.sh 0 1
```

- 按层级运行，先跑 0 和 1。已完成的作业（有 `completed.properties`）会自动跳过，中断后重新执行同一命令即可续跑。
- 每个作业在自己的文件夹里编译并运行，生成 `completed.properties`、结果 CSV、`*.field.csv`（应变与 J 检查）、`solver.log` 和 `.mph`。
- 多台机器或多核时可以把不同层级或不同作业分开跑；`-Cores` 限制每个作业的核数。
- **不要修改任何作业文件夹里的 `UltraResearch.java`、`scene.json`、`parameters.json`。** 改动后哈希不符，结果无法收集。

## 作业清单

| 文件夹 | 层级 | 工况 | 本构 | 变体 | h (mm) | 最大步长 (μs) | 用途 |
|---|---|---|---|---|---|---|---|
| 00-material-check | 0 | material-check | murnaghan | base | 1.0 | 0.01 | 本构自检（单个单元，几分钟） |
| 01-A-f0.40-T1.6-murnaghan | 1 | A-f0.40-T1.6 | murnaghan | base | 0.8 | 0.01 | 非线性增量：Murnaghan 基准 |
| 02-B-f0.40-T1.6-murnaghan | 1 | B-f0.40-T1.6 | murnaghan | base | 0.8 | 0.01 | 非线性增量：Murnaghan 基准 |
| 03-C-f0.25-T2.0-murnaghan | 1 | C-f0.25-T2.0 | murnaghan | base | 0.8 | 0.01 | 非线性增量：Murnaghan 基准 |
| 04-A-f0.40-T1.6-linear | 1 | A-f0.40-T1.6 | linear | base | 0.8 | 0.01 | 非线性增量：同一源码的线性基准（与已归档线性结果互为复现检查） |
| 05-B-f0.40-T1.6-linear | 1 | B-f0.40-T1.6 | linear | base | 0.8 | 0.01 | 非线性增量：同一源码的线性基准（与已归档线性结果互为复现检查） |
| 06-C-f0.25-T2.0-linear | 1 | C-f0.25-T2.0 | linear | base | 0.8 | 0.01 | 非线性增量：同一源码的线性基准（与已归档线性结果互为复现检查） |
| 07-A-f0.40-T1.6-stvk | 2 | A-f0.40-T1.6 | stvk | base | 0.8 | 0.01 | 区分几何非线性与材料非线性：StVK 基准 |
| 08-B-f0.40-T1.6-stvk | 2 | B-f0.40-T1.6 | stvk | base | 0.8 | 0.01 | 区分几何非线性与材料非线性：StVK 基准 |
| 09-C-f0.25-T2.0-stvk | 2 | C-f0.25-T2.0 | stvk | base | 0.8 | 0.01 | 区分几何非线性与材料非线性：StVK 基准 |
| 10-A-f0.40-T1.6-linear-dt2 | 3 | A-f0.40-T1.6 | linear | dt2 | 0.8 | 0.005 | A 工况时间收敛 |
| 11-A-f0.40-T1.6-murnaghan-dt2 | 3 | A-f0.40-T1.6 | murnaghan | dt2 | 0.8 | 0.005 | A 工况时间收敛 |
| 12-A-f0.40-T1.6-linear-mesh2 | 3 | A-f0.40-T1.6 | linear | mesh2 | 0.56 | 0.01 | A 工况网格收敛 |
| 13-A-f0.40-T1.6-murnaghan-mesh2 | 3 | A-f0.40-T1.6 | murnaghan | mesh2 | 0.56 | 0.01 | A 工况网格收敛 |
| 14-B-f0.40-T1.6-linear-dt2 | 4 | B-f0.40-T1.6 | linear | dt2 | 0.8 | 0.005 | B 工况时间收敛 |
| 15-B-f0.40-T1.6-murnaghan-dt2 | 4 | B-f0.40-T1.6 | murnaghan | dt2 | 0.8 | 0.005 | B 工况时间收敛 |
| 16-B-f0.40-T1.6-linear-mesh2 | 4 | B-f0.40-T1.6 | linear | mesh2 | 0.56 | 0.01 | B 工况网格收敛 |
| 17-B-f0.40-T1.6-murnaghan-mesh2 | 4 | B-f0.40-T1.6 | murnaghan | mesh2 | 0.56 | 0.01 | B 工况网格收敛 |
| 18-C-f0.25-T2.0-linear-dt2 | 4 | C-f0.25-T2.0 | linear | dt2 | 0.8 | 0.005 | C 工况时间收敛 |
| 19-C-f0.25-T2.0-murnaghan-dt2 | 4 | C-f0.25-T2.0 | murnaghan | dt2 | 0.8 | 0.005 | C 工况时间收敛 |
| 20-C-f0.25-T2.0-linear-mesh2 | 4 | C-f0.25-T2.0 | linear | mesh2 | 0.56 | 0.01 | C 工况网格收敛 |
| 21-C-f0.25-T2.0-murnaghan-mesh2 | 4 | C-f0.25-T2.0 | murnaghan | mesh2 | 0.56 | 0.01 | C 工况网格收敛 |

- 层级 0：本构自检，几分钟。必须通过，否则不要继续。
- 层级 1：三个工况的 Murnaghan 与同一源码的线性运行，用来算非线性增量。已归档的线性结果来自没有归档的另一份源码，所以线性要用同一源码重算一次；它与旧结果的差异同时就是复现检查。
- 层级 2：StVK，区分几何非线性和材料非线性。
- 层级 3：A 工况的时间步减半（dt2）和网格加密（mesh2），检查 COMSOL 自身是否收敛。
- 层级 4：B、C 工况的收敛检查。层级 3 显示收敛良好时可以不跑。

已归档的线性运行在原服务器上每次约 24–30 小时（2.2–3.1 万自由度）。非线性运行估计约为线性的 1.5–3 倍，dt2 约 2 倍，mesh2 约 4–6 倍；以实测为准。

## 跑完以后

把整个 `runs/` 文件夹打包发回即可（`.mph` 可以不带）。也可以自己转换并检查：

```sh
python research/comsol-p1-20261024/local_kit.py collect runs --output p1-delivery
python -m coarsegraph.comsol check p1-delivery --partial
```

import com.comsol.model.Model;

public class P1DofCheck {
    public static Model run() throws Exception {
        return UltraResearch.checkMesh();
    }
    public static void main(String[] args) throws Exception {
        run();
    }
}

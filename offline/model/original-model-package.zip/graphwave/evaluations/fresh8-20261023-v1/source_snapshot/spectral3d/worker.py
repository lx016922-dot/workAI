"""Bounded interactive high-order solve; no AI or remote computation."""
import argparse,copy,json,signal,time
from pathlib import Path
import numpy as np
from solid.schema import validate_scene
from .campaign import atomic,now,digest
from .mesh import make_mesh,boundary_data,interpolation
from .result import result_record,surface_triangles


def run(directory):
    directory=Path(directory);started=time.monotonic();status={'job_id':directory.name,'phase':'meshing','started_at_utc':now()}
    def publish(**values):
        status.update(values,updated_at_utc=now(),elapsed_s=time.monotonic()-started);atomic(directory/'status.json',status)
    def timeout(*_):raise TimeoutError('高阶计算超过 30 分钟预算，任务已停止。')
    signal.signal(signal.SIGALRM,timeout);signal.alarm(1800)
    try:
        scene_path=directory/'scene.json';raw=json.loads(scene_path.read_text());settings=json.loads((directory/'settings.json').read_text())
        if not {'degree'}<=set(settings)<= {'degree','material_model','decompose'} or type(settings['degree']) is not int or settings['degree'] not in [3,4]:raise ValueError('高阶阶次应为 3 或 4。')
        if 'decompose' in settings and type(settings['decompose']) is not bool:raise ValueError('响应分解选项必须为布尔值。')
        decompose=settings.get('decompose',False)
        h=raw['numerics']['h_mm']
        if type(h) not in [int,float] or not np.isfinite(h) or not .02<=h<=100:raise ValueError('高阶单元尺寸必须在 0.02–100 mm 范围内。')
        raw['numerics']['h_mm']=max(.02,h/settings['degree']);scene=validate_scene(raw);scene['numerics']['h_mm']=h
        if scene['geometry']['kind'] not in ['plate','pipe','hole','notch']:raise ValueError('高阶计算支持参数化板、管、通孔和缺口。')
        if scene['source']['face'] not in ['xmin','xmax'] or scene['source']['radius_mm']!=0 or scene['boundary']['fixed_face'] not in ['none','xmin','xmax']:
            raise ValueError('当前高阶计算使用完整 X 端面加载，固定面可选另一 X 端面。')
        requested_scene=copy.deepcopy(scene);material_model=None
        if decompose and scene['constitutive']!='murnaghan':raise ValueError('响应分解需要 Murnaghan 本构。')
        if 'material_model' in settings:
            from energyai.release import load_release
            from energyai.model import effective_material
            release,learned=load_release(directory.parents[2])
            if any(settings['material_model'].get(k)!=release[k] for k in ['run_id','evaluation_id','checkpoint_sha256','weights_manifest_sha256','metrics_sha256']):raise ValueError('材料学习版本在任务创建后改变。')
            scene['material']=effective_material(scene['material'],learned)
            material_model={**settings['material_model'],'constants_pa':learned['constants_pa'],'pure_neural_transient_operator':False,'accepted_for_learned_material_use':True}
            atomic(directory/'effective-scene.json',scene);status['kind']='learned_material_energy'
        hashes={};source=Path(__file__).resolve().parents[1]
        for module in (['solid','spectral3d','energyai'] if material_model else ['solid','spectral3d']):
            target=directory/'source_snapshot'/module;target.mkdir(parents=True,exist_ok=False)
            for file in (source/module).glob('*.py'):
                (target/file.name).write_bytes(file.read_bytes());hashes[module+'/'+file.name]=digest(file)
        publish();mesh=make_mesh(scene,settings['degree'],scene['numerics']['h_mm'])
        frames=round(scene['acquisition']['duration_us']/scene['acquisition']['sample_step_us'])+1
        if len(mesh['points'])>30000 or len(mesh['elements'])>scene['numerics']['max_elements'] or mesh['elements'].size>100000 or len(mesh['points'])*frames*24>192*1024**2 or len(surface_triangles(mesh['elements']))>50000:
            raise ValueError('高阶网格或场存储超出预算；请增大网格尺寸或缩短记录。')
        boundary_data(mesh,scene)
        for receiver in scene['receivers']:interpolation(mesh,receiver['point_mm'])
        np.savez_compressed(directory/'mesh.npz',**mesh)
        def progress(value):publish(phase='running',step=value.get('frame',0),steps_total=frames-1)
        publish(phase='running',step=0,steps_total=frames-1,nodes=len(mesh['points']))
        if decompose:
            from .decomposition import solve_controls,export_parts
            def control_progress(law,index,frame):
                publish(phase='running',control=law,controls_total=3,controls_completed=index,
                        step=index*(frames-1)+frame,steps_total=3*(frames-1))
            computed,control_fields,controls=solve_controls(directory/'controls',scene,mesh,control_progress)
        elif scene['geometry']['kind']=='hole':
            from .implicit import solve
            computed=solve(scene,mesh,substeps=4,keep_fields=True,callback=progress)
        else:
            from .solver import solve
            computed=solve(scene,mesh,cfl=scene['numerics']['cfl'],keep_fields=True,callback=progress)
        publish(phase='exporting',step=(3 if decompose else 1)*(frames-1),**({'controls_completed':3} if decompose else {}))
        record,packed=result_record(directory.name,scene,mesh,computed)
        if material_model:
            record.update(schema='workai.learned_energy.result.v1',engine='workai_learned_energy_3d',engine_scope='learned_material_energy_with_full_numerical_propagation',material_model=material_model,requested_scene=requested_scene,effective_scene_sha256=digest(directory/'effective-scene.json'))
        record.update(scene_sha256=digest(scene_path),settings_sha256=digest(directory/'settings.json'),
                      mesh_sha256=digest(directory/'mesh.npz'),source_sha256=hashes)
        if decompose:
            record['response_parts'],record['control_study']=export_parts(directory,control_fields,controls,record['field'],record['mesh_sha256'])
        np.savez_compressed(directory/'probes.npz',probes_m=computed['probes_m'],times_us=computed['times_us'])
        (directory/'field.bin.gz').write_bytes(packed);atomic(directory/'result.json',record)
        publish(phase='completed',result_sha256=digest(directory/'result.json'),accepted_for_solver_routing=False)
    except BaseException as error:
        publish(phase='failed',error=str(error));raise
    finally:signal.alarm(0)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--job-dir',type=Path,required=True);run(parser.parse_args().job_dir)

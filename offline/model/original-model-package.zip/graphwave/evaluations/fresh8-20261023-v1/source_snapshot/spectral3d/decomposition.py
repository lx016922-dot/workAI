"""Three matched transient controls, with subtraction in float64 before export."""
import copy
import numpy as np
from .campaign import atomic,digest
from .mesh import boundary_data
from .result import pack_field

PARTS={'full':'murnaghan','linear':'linear','stvk':'stvk',
       'geometric':'stvk - linear','material':'murnaghan - stvk'}


def solve_controls(directory,scene,mesh,progress):
    directory.mkdir(exist_ok=True)
    fields={};controls={};times=None;baseline=None
    _,fixed,_=boundary_data(mesh,scene)
    if scene['constitutive']!='murnaghan':raise ValueError('响应分解需要完整 Murnaghan 场景。')
    prepared=None
    if scene['geometry']['kind']=='hole':
        from .implicit import solve,prepare
        prepared=prepare(scene,mesh,substeps=4)
    else:
        from .solver import solve
    for index,law in enumerate(['linear','stvk','murnaghan']):
        current=copy.deepcopy(scene);current['constitutive']=law
        target=directory/law;target.mkdir(exist_ok=False);atomic(target/'scene.json',current)
        progress(law,index,0)
        callback=lambda value:progress(law,index,value.get('frame',0))
        options={'substeps':4,'prepared':prepared} if prepared is not None else {'cfl':scene['numerics']['cfl']}
        result=solve(current,mesh,keep_fields=True,callback=callback,**options)
        d=result['diagnostics'];field=result['fields_m']
        signature=(d['method'],d['internal_steps'],d['internal_step_us'])
        if times is not None and (not np.array_equal(times,result['times_us']) or signature!=baseline):
            raise ValueError('三个控制必须采用同一时间网格和积分器。')
        if not np.isfinite(field).all() or np.any(field[0]) or (len(fixed) and np.any(field[:,fixed])):
            raise ValueError('控制场的初始条件或固定边界检查失败。')
        if not np.isfinite(d['external_work_balance_relative']) or d['external_work_balance_relative']>.01 or d['max_strain']>.001 or d['min_J']<=0:
            raise ValueError(f'{law} 控制的能量、应变或 J 检查未通过。')
        times=result['times_us'];baseline=signature;fields[law]=field
        np.savez_compressed(target/'probes.npz',probes_m=result['probes_m'],times_us=times)
        atomic(target/'diagnostics.json',d)
        controls[law]={'scene_sha256':digest(target/'scene.json'),'probes_sha256':digest(target/'probes.npz'),
                       'diagnostics':d,'zero_initial':True,'zero_fixed':True}
    return result,fields,controls


def export_parts(directory,fields,controls,full_descriptor,mesh_sha256):
    destination=directory/'parts';destination.mkdir(exist_ok=False)
    parts={'full':{'definition':PARTS['full'],'field':full_descriptor,'diagnostics':controls['murnaghan']['diagnostics']}}
    for part in ['linear','stvk','geometric','material']:
        values=fields[part] if part in ['linear','stvk'] else fields['stvk']-fields['linear'] if part=='geometric' else fields['murnaghan']-fields['stvk']
        field,packed=pack_field(values);(destination/(part+'.bin.gz')).write_bytes(packed)
        # Difference fields are responses, not separately integrated physical states.
        law=part if part in ['linear','stvk'] else 'murnaghan'
        parts[part]={'definition':PARTS[part],'field':field,'diagnostics':controls[law]['diagnostics']}
    for law,part in [('linear','linear'),('stvk','stvk'),('murnaghan','full')]:controls[law]['field']=parts[part]['field']
    study={'schema':'workai.spectral_decomposition.v1','mesh_sha256':mesh_sha256,
           'shared_mesh':True,'shared_time_grid':True,'shared_integrator':True,'subtraction_dtype':'float64',
           'controls':controls,'difference_energy_is_not_separate_physical_energy':True,
           'material_difference_includes_geometric_coupling':True,'numerical_convergence_verified':False}
    return parts,study

"""Physical null control and exact fixed/initial conditions for decomposition."""
import tempfile,unittest
from pathlib import Path
import numpy as np
from solid.schema import default_scene
from .mesh import make_mesh,boundary_data
from .decomposition import solve_controls


class DecompositionTests(unittest.TestCase):
    def test_zero_third_order_constants_remove_material_increment(self):
        scene=default_scene();scene['geometry'].update(length_mm=4.,width_mm=2.,thickness_mm=2.)
        scene['source'].update(frequency_mhz=.3,cycles=1.5,amplitude_mpa=.7,direction=[1.,.08,-.05],center_mm=[0.,1.,1.])
        scene['boundary']['fixed_face']='xmax';scene['acquisition'].update(duration_us=8.,sample_step_us=.05)
        scene['receivers']=[{'name':'interior','point_mm':[1.5,1.,1.],'direction':[2.,-3.,1.]}]
        scene['material'].update(l_pa=0.,m_pa=0.,n_pa=0.);scene['numerics']['cfl']=.2
        mesh=make_mesh(scene,3,1.);_,fixed,_=boundary_data(mesh,scene)
        with tempfile.TemporaryDirectory(prefix='workai-null-control-') as path:
            progress=[];full,fields,controls=solve_controls(Path(path),scene,mesh,lambda law,index,frame:progress.append((law,index,frame)))
        np.testing.assert_array_equal(fields['murnaghan'],fields['stvk'])
        self.assertGreater(float(np.linalg.norm(fields['stvk']-fields['linear'])),1e-14)
        for field in fields.values():
            np.testing.assert_array_equal(field[0],0);np.testing.assert_array_equal(field[:,fixed],0)
        self.assertEqual({x[0] for x in progress},{'linear','stvk','murnaghan'})
        self.assertEqual(len({d['diagnostics']['internal_step_us'] for d in controls.values()}),1)


if __name__=='__main__':unittest.main()

import unittest
import torch
from .identify import basis,SCALE


def energy(gradient,constants):
    f=torch.eye(3,dtype=gradient.dtype)+gradient;e=.5*(f.T@f-torch.eye(3,dtype=gradient.dtype));tr=torch.trace(e);tr2=torch.trace(e@e);tr3=torch.trace(e@e@e);l,m,n=constants
    return l*tr**3/3+m*(tr*tr2-tr**3/3)+n*(tr3/3-.5*tr*tr2+tr**3/6)


class LearnedEnergyTests(unittest.TestCase):
    def test_stress_is_derivative_of_objective_energy(self):
        g=torch.tensor([[.0002,.0001,-.00003],[.00007,-.00012,.00002],[.00004,.00001,.00008]],dtype=torch.float64,requires_grad=True);constants=torch.tensor([-1.71e11,-2.86e11,-3.24e11],dtype=torch.float64)
        exact=torch.autograd.grad(energy(g,constants),g)[0];predicted=torch.einsum('ijk,k->ij',basis(g),constants/SCALE);torch.testing.assert_close(predicted,exact,rtol=5e-11,atol=1e-7)

    def test_frame_objectivity(self):
        g=torch.diag(torch.tensor([.0002,-.0001,.00003],dtype=torch.float64));angle=torch.tensor(.7,dtype=torch.float64);r=torch.tensor([[torch.cos(angle),-torch.sin(angle),0.],[torch.sin(angle),torch.cos(angle),0.],[0.,0.,1.]],dtype=torch.float64);rotated=r@(torch.eye(3)+g)-torch.eye(3);torch.testing.assert_close(basis(rotated),torch.einsum('ij,jkl->ikl',r,basis(g)),rtol=1e-8,atol=1e-7)

    def test_zero_strain_has_zero_nonlinear_stress(self):
        torch.testing.assert_close(basis(torch.zeros((3,3),dtype=torch.float64)),torch.zeros((3,3,3),dtype=torch.float64),rtol=0,atol=0)


if __name__=='__main__':unittest.main()

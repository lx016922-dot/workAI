"""Frozen learned-energy evaluation on new complete geometries and fields."""
import argparse,gc,json,os,shutil,subprocess,time
from pathlib import Path
import numpy as np
import torch
from spectral3d.compare import spectral,compare,complex_coefficient,digest
from spectral3d.field_compare import field,weighted
from spectralop.data import tensors
from spectralop.physics import star,internal
from operator3d.physics import U0,T0,pulse
from operator3d.train import atomic,now
from .model import load_model,effective_material


def physics_checks(case,parts,scales):
    targets=np.flatnonzero(~case['fixed'].numpy());patch=star(case,targets);ids=patch['ids'].numpy();dt=case['times'][1]-case['times'][0];rows=[];zero_peak=0.
    with torch.no_grad():
        for frame in np.unique(np.linspace(10,len(parts)-4,9,dtype=int)):
            values=torch.as_tensor(parts[frame-2:frame+3,ids]/U0,dtype=torch.float64);force,strain,jac=internal(values[2],case,patch)
            acceleration=(-values[4]+16*values[3]-30*values[2]+16*values[1]-values[0])[patch['at']]/(12*dt**2)
            target=patch['targets'];ext=case['load'][target]*pulse(torch.tensor(case['times'][frame]),case['scene']['source']);ext=torch.stack([ext,ext*0,ext*0],1)
            normal=scales[:,None]*(2*torch.pi*case['scene']['source']['frequency_mhz'])**2;mass=case['mass'][target];residual=acceleration+(force-ext)/(mass[:,None,None]*(U0/T0**2));squared=(residual/normal).square().mean(2);boundary=case['boundary_nodes'][target]
            def rms(mask):return torch.sqrt((squared[mask]*mass[mask,None]).sum(0)/mass[mask].sum()).tolist() if mask.any() else [0.,0.,0.]
            zero=ext/(mass[:,None,None]*(U0/T0**2))/normal
            if boundary.any():zero_peak=max(zero_peak,float(torch.sqrt((zero[boundary].square().mean(2)*mass[boundary,None]).sum(0)/mass[boundary].sum()).max()))
            rows.append({'time_us':float(case['times'][frame]),'interior_branch_rms':rms(~boundary),'boundary_branch_rms':rms(boundary),'max_strain':float(torch.linalg.matrix_norm(strain,dim=(-2,-1)).max()),'min_J':float(jac.min())})
    return {'checks':rows,'all_free_nodes_checked':len(targets),'time_frames_checked':len(rows),'stencil':'fourth-order five-point central acceleration at output interval','normalization_from_previous_training_only':True,'zero_field_boundary_rms_peak':zero_peak,'zero_field_rejected':zero_peak>.05,'passed':all(max(r['interior_branch_rms']+r['boundary_branch_rms'])<=.05 for r in rows) and zero_peak>.05}


def run(args):
    out=args.output;out.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);model=load_model(args.model);frozen=model['checkpoint_sha256'];started=time.monotonic();deadline=started+14400
    repo=Path(__file__).resolve().parents[1];source_hashes={}
    for module in ['energyai','spectralop','spectral3d','operator3d','solid']:
        dest=out/'source_snapshot'/module;dest.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,dest/path.name);source_hashes[module+'/'+path.name]=digest(path)
    atomic(out/'evaluation-source.json',source_hashes)
    status={'schema':'workai.learned_energy_evaluation.v1','phase':'waiting_for_references','checkpoint_sha256':frozen,'started_at_utc':now(),'cases':[],'accepted_for_solver_routing':False};atomic(out/'status.json',status)
    while True:
        reference=json.loads(args.references.read_text())
        if reference['phase']=='completed':break
        if time.monotonic()>deadline:raise TimeoutError('Fresh reference validation did not finish.')
        time.sleep(5)
    if not reference['all_reference_checks_passed']:raise ValueError('Fresh references did not pass all fixed quality gates.')
    assert reference['frozen_checkpoint_sha256']==frozen;input_plan=json.loads((args.references.parent/'planned-inputs.json').read_text());assert digest(args.model/'weights.json')==input_plan['frozen_weights_manifest_sha256']
    scales=torch.tensor(json.loads((args.model/'source-dataset.json').read_text())['branch_scales_in_100nm'],dtype=torch.float64);rows=[];probes={}
    manifest={'schema':'workai.learned_energy_evaluation_plan.v1','reference_manifest_sha256':digest(args.references),'checkpoint_sha256':frozen,'weights_manifest_sha256':digest(args.model/'weights.json'),'evaluation_source_sha256':source_hashes,'threshold':.05,'test_geometry_count':len(reference['cases']),'physical_residual':'all free nodes at nine fixed time frames, five-point acceleration, unchanged 5% normalized threshold','accepted_for_solver_routing':False};atomic(out/'plan.json',manifest)
    for item in reference['cases']:
        cid=item['case_id'];base=Path(item['base_manifest']);assert digest(base)==item['base_manifest_sha256'];teacher=json.loads(base.read_text());assert digest(Path(item['quality_path']))==item['quality_sha256'];quality=json.loads(Path(item['quality_path']).read_text());assert quality['passed']
        status.update(phase='predicting',current_case=cid,elapsed_s=time.monotonic()-started);atomic(out/'status.json',status)
        request={'case_id':cid,'scene':item['scene'],'checkpoint_sha256':frozen,**{k:teacher[k] for k in ['degree','h_mm','cfl','integrator','substeps']}};path=out/(cid+'-input.json');atomic(path,request);directory=out/cid
        command=['/workspace/workai-remote/solid/venv/bin/python','-m','energyai.predict','--input',str(path),'--model',str(args.model),'--output',str(directory)]
        with (out/(cid+'.log')).open('x') as log:subprocess.run(command,cwd=out/'source_snapshot',env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
        prediction_path=directory/'manifest.json';prediction=json.loads(prediction_path.read_text());pitem=prediction['cases'][0];titem=teacher['cases'][0];assert not prediction['reference_responses_read_for_inference'];pred_summary=spectral(prediction_path);true_summary=spectral(base);trace=compare(pred_summary,true_summary)['cases'][0]
        with np.load(directory/pitem['mesh_file'],allow_pickle=False) as saved:mesh=dict(saved)
        with np.load(base.parent/titem['mesh_file'],allow_pickle=False) as saved:
            for key in mesh:np.testing.assert_array_equal(mesh[key],saved[key])
        predictions=[field(directory,pitem,law) for law in ['linear','stvk','murnaghan']];truths=[field(base.parent,titem,law) for law in ['linear','stvk','murnaghan']]
        for control in pitem['controls']:
            actual=json.loads((directory/control['directory']/'scene.json').read_text());expected=effective_material(item['scene']['material'],model) if control['law']=='murnaghan' else item['scene']['material'];assert actual['material']==expected
        pparts=np.stack([predictions[0],predictions[1]-predictions[0],predictions[2]-predictions[1]],2);tparts=np.stack([truths[0],truths[1]-truths[0],truths[2]-truths[1]],2);checks={}
        for name,p,t in [('full',predictions[2],truths[2]),('material',pparts[:,:,2],tparts[:,:,2]),('geometric',pparts[:,:,1],tparts[:,:,1])]:
            checks[name+'_vector']=weighted(p,t,mesh['mass'])
            for axis,label in enumerate('xyz'):checks[name+'_'+label]=weighted(p[:,:,axis:axis+1],t[:,:,axis:axis+1],mesh['mass'])
        case=tensors(item['scene'],mesh);case['times']=pred_summary[cid]['times'];physical=physics_checks(case,pparts,scales)
        for i,probe in enumerate(trace['probes']):
            direction=np.asarray(item['scene']['receivers'][i]['direction']);direction/=np.linalg.norm(direction);p=pred_summary[cid]['parts'][:,i];t=true_summary[cid]['parts'][:,i];pc=complex_coefficient(case['times'],p[:,2]@direction,2*item['scene']['source']['frequency_mhz']);tc=complex_coefficient(case['times'],t[:,2]@direction,2*item['scene']['source']['frequency_mhz']);probe.update(direction=direction.tolist(),full_waveform_relative_l2=probe['checks']['full_requested']['relative_l2'],material_waveform_relative_l2=probe['checks']['material_requested']['relative_l2'],material_2f_predicted_nm=float(abs(pc)*1e9),material_2f_fem_nm=float(abs(tc)*1e9),material_2f_complex_relative_error=float(abs(pc-tc)/abs(tc)) if abs(tc)>1e-13 else None)
            probes[cid+f'_P{i+1}_prediction']=p;probes[cid+f'_P{i+1}_fem']=t
        probes[cid+'_times_us']=case['times'];diagnostics=pred_summary[cid]['diagnostics'];guard=all(d['max_strain']<=.001 and d['min_J']>0 and d['energy_balance_within_1_percent'] for d in diagnostics);initial=bool(np.all(pparts[0]==0));fixed=bool(np.all(pparts[:,case['fixed'].numpy()]==0))
        row={'case_id':cid,'split':'test','scene':item['scene'],'source':item['scene']['source'],'field_checks':checks,'probes':trace['probes'],'probe_checks_pass':trace['all_probe_checks_pass'],'physical_checks':physical,'energy_strain_J_pass':guard,'exact_initial_and_fixed':initial and fixed,'reference_checks_passed':True,'prediction_manifest':str(prediction_path),'prediction_manifest_sha256':digest(prediction_path),'reference_manifest':str(base),'reference_manifest_sha256':digest(base)};rows.append(row);status['cases'].append({'case_id':cid,'phase':'evaluated'});atomic(out/'status.json',status);atomic(out/'partial-results.json',rows)
        print(json.dumps({'evaluated':cid,'full':checks['full_vector']['relative_l2'],'material':checks['material_vector']['relative_l2'],'physics_passed':physical['passed'],'probes_passed':row['probe_checks_pass']}),flush=True)
        del case,pparts,tparts,predictions,truths,mesh;gc.collect()
    np.savez_compressed(out/'probe-predictions.npz',**probes);assert digest(args.model/'best.pt')==frozen
    gates={'fresh_test_geometries':len(rows)==8,'reference_h_p_time_full_fields':all(r['reference_checks_passed'] for r in rows),'full_field_and_components':all(c['pass'] for r in rows for c in r['field_checks'].values()),'receivers_and_material_2f':all(r['probe_checks_pass'] for r in rows),'all_node_sampled_time_physics':all(r['physical_checks']['passed'] for r in rows),'energy_strain_positive_J':all(r['energy_strain_J_pass'] for r in rows),'exact_initial_and_fixed':all(r['exact_initial_and_fixed'] for r in rows)}
    metrics={'schema':'workai.learned_energy_metrics.v1','kind':'learned_material_energy','checkpoint_sha256':frozen,'weights_manifest_sha256':digest(args.model/'weights.json'),'constants_pa':model['constants_pa'],'new_training_steps':2000,'selected_step':model['selected_step'],'cases':rows,'acceptance':{'threshold':.05,**gates,'all_gates_passed':all(gates.values())},'probe_archive_sha256':digest(out/'probe-predictions.npz'),'test_used_for_checkpoint_selection':False,'pure_neural_transient_operator':False,'accepted_for_solver_routing':False,'accepted_for_learned_material_use':all(gates.values()),'scope':'Same sourced aluminum law and bounded four-family geometry range; learned material + full numerical propagation. Synthetic-data verification, not a universal neural surrogate or experimental validation.','completed_at_utc':now()};atomic(out/'metrics.json',metrics);status.update(phase='completed',elapsed_s=time.monotonic()-started);atomic(out/'status.json',status);print(json.dumps({'completed':True,'acceptance':metrics['acceptance']}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--model',type=Path,required=True);parser.add_argument('--references',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);run(parser.parse_args())

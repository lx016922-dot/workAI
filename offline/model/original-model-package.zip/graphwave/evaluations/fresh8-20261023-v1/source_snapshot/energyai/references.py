"""Fresh geometry evaluation references, generated after material-weight freeze."""
import argparse,json,os,shutil,subprocess,sys,threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from spectral3d.dataset import plan
from spectral3d.compare import spectral,compare,digest
from spectral3d.field_compare import compare_fields
from spectral3d.campaign import atomic,now
from operator3d.campaign import geometry_identity


def run(args):
    root=args.output;root.mkdir(parents=True,exist_ok=False);weights=json.loads((args.model/'weights.json').read_text());assert digest(args.model/'best.pt')==weights['checkpoint_sha256'];repo=Path(__file__).resolve().parents[1];hashes={}
    for module in ['solid','spectral3d','operator3d','energyai']:
        dest=root/'source_snapshot'/module;dest.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,dest/path.name);hashes[module+'/'+path.name]=digest(path)
    old=[]
    for path in [args.prior,Path('/workspace/workai-remote/modal3d/campaigns/holdout64-20261023/manifest.json')]:
        old.extend(geometry_identity(c['scene']) for c in json.loads(path.read_text())['cases'])
    cases=[]
    for c in plan(seed=2026102357)['cases']:
        if c['case_id'].rsplit('-',1)[-1] not in ['0','3']:continue
        kind=c['scene']['geometry']['kind'];variant='free' if c['scene']['boundary']['fixed_face']=='none' else 'fixed';cid='energy-test-'+kind+'-'+variant;c.update(case_id=cid,split='test',phase='waiting');c['scene']['name']=cid;c['geometry_group_sha256']=geometry_identity(c['scene']);assert c['geometry_group_sha256'] not in old;cases.append(c)
    assert len(cases)==8 and len({c['geometry_group_sha256'] for c in cases})==8
    inputs={'schema':'workai.energyai_fresh_inputs.v1','cases':cases,'seed':2026102357,'created_at_utc':now(),'frozen_checkpoint_sha256':weights['checkpoint_sha256'],'frozen_weights_manifest_sha256':digest(args.model/'weights.json'),'test_scope':'Eight new geometries after energy-layer freeze. No fitting or weight selection from these responses.'};atomic(root/'planned-inputs.json',inputs)
    manifest={'schema':'workai.energyai_fresh_references.v1','phase':'running','created_at_utc':now(),'planned_inputs_sha256':digest(root/'planned-inputs.json'),'source_sha256':hashes,'frozen_checkpoint_sha256':weights['checkpoint_sha256'],'threshold':.05,'cases':[{'case_id':c['case_id'],'scene':c['scene'],'phase':'waiting'} for c in cases],'rule':'Fixed p4/h1.4 for plate/notch, p3/h1.4 for pipe, p4/h2 for hole; if any 5% check fails, p4/h1 fallback. No prediction used to choose references.'};lock=threading.RLock()
    def publish():
        with lock:manifest['updated_at_utc']=now();atomic(root/'manifest.json',manifest)
    def solve(case,label,p,h,cfl=.3,substeps=4,fields=True):
        path=root/case['case_id']/label;command=[sys.executable,'-m','spectral3d.campaign','--campaign',str(root/'planned-inputs.json'),'--output',str(path),'--cases',case['case_id'],'--degree',str(p),'--h',str(h),'--cfl',str(cfl),'--substeps',str(substeps),'--integrator','newmark' if case['scene']['geometry']['kind']=='hole' else 'verlet']
        if fields:command.append('--fields')
        with (path.parent/(label+'.log')).open('x') as log:subprocess.run(command,cwd=root/'source_snapshot',env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
        return path/'manifest.json'
    def check(paths,dest):
        baseline=spectral(paths['base']);result={name:compare(baseline,spectral(paths[name])) for name in ['space','degree','time']};result['field']=compare_fields(paths['base'],paths['space']);result['levels']={k:{'manifest':str(v),'sha256':digest(v)} for k,v in paths.items()};result['guards_passed']=all(d['energy_balance_within_1_percent'] and d['max_strain']<=.001 and d['min_J']>0 for path in paths.values() for c in spectral(path).values() for d in c['diagnostics']);result['passed']=result['guards_passed'] and result['field']['all_checks_pass'] and all(result[k]['all_probe_checks_pass'] for k in ['space','degree','time']);atomic(dest,result);return result['passed']
    def work(case,row):
        directory=root/case['case_id'];directory.mkdir()
        try:
            kind=case['scene']['geometry']['kind'];p=3 if kind=='pipe' else 4;h=2. if kind=='hole' else 1.4;row.update(phase='solving',degree=p,h_mm=h);publish()
            paths={'base':solve(case,'base',p,h),'space':solve(case,'space',p,1.4 if kind=='hole' else 1.),'degree':solve(case,'degree',p+1,h,fields=False),'time':solve(case,'time',p,h,.15,8,fields=False)}
            path=directory/'quality.json';passed=check(paths,path);row['attempts']=[{'quality_path':str(path),'sha256':digest(path),'passed':passed}]
            if not passed:
                row['phase']='refining';publish();paths={'base':solve(case,'refined-base',4,1.),'space':solve(case,'refined-space',4,.75),'degree':solve(case,'refined-degree',5,1.,fields=False),'time':solve(case,'refined-time',4,1.,.15,8,fields=False)};path=directory/'refined-quality.json';passed=check(paths,path);row['attempts'].append({'quality_path':str(path),'sha256':digest(path),'passed':passed})
            row.update(phase='completed',reference_checks_passed=passed,base_manifest=str(paths['base']),base_manifest_sha256=digest(paths['base']),quality_path=str(path),quality_sha256=digest(path),levels={k:{'manifest':str(v),'sha256':digest(v)} for k,v in paths.items()});publish();print(json.dumps({'case_id':case['case_id'],'passed':passed}),flush=True)
        except BaseException as error:row.update(phase='failed',error=str(error),reference_checks_passed=False);publish();print(json.dumps({'case_id':case['case_id'],'error':str(error)}),flush=True)
    publish()
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda pair:work(*pair),zip(cases,manifest['cases'])))
    manifest.update(phase='completed',all_reference_checks_passed=all(c.get('reference_checks_passed',False) for c in manifest['cases']),completed_at_utc=now());publish()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--model',type=Path,required=True);parser.add_argument('--prior',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);run(parser.parse_args())

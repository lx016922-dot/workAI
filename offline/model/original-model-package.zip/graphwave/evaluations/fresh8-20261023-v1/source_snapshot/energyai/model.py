"""Load frozen learned material coefficients without a Torch runtime."""
import json,math
from pathlib import Path
from spectral3d.compare import digest


def load_model(directory):
    directory=Path(directory);path=directory/'weights.json';weights=json.loads(path.read_text());config=json.loads((directory/'config.json').read_text())
    if weights['schema']!='workai.learned_energy_weights.v1' or weights['pure_neural_transient_operator'] is not False:raise ValueError('Learned-energy model schema mismatch.')
    if digest(directory/'best.pt')!=weights['checkpoint_sha256'] or digest(directory/'weak-equations.npz')!=weights['equations_sha256']:raise ValueError('Frozen material model hash mismatch.')
    for name,sha in config['source_sha256'].items():
        if digest(directory/'source_snapshot'/name)!=sha:raise ValueError('Frozen material training source mismatch.')
    values=weights['constants_pa']
    if len(values)!=3 or not all(isinstance(x,(int,float)) and math.isfinite(x) and abs(x)<=1e12 for x in values):raise ValueError('Learned material parameters are outside the supported range.')
    return {**weights,'weights_manifest_sha256':digest(path)}


def effective_material(nominal,model):
    result=dict(nominal);result.update(dict(zip(['l_pa','m_pa','n_pa'],model['constants_pa'])));return result

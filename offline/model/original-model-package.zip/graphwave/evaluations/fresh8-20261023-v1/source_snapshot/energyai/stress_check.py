"""Independent strain/orientation checks of the frozen learned material only.

These synthetic constitutive checks do not extend transient geometry acceptance.
"""
import argparse,json
from pathlib import Path
import numpy as np
import torch
from operator3d.physics import piola
from solid.schema import default_scene
from spectral3d.compare import digest
from .model import load_model,effective_material


def main(a):
    torch.set_num_threads(1);model=load_model(a.model);nominal=default_scene('plate')['material'];learned=effective_material(nominal,model);rng=np.random.default_rng(2026102379);eye=np.eye(3)
    gradients=[]
    for _ in range(1024):
        e=rng.normal(size=(3,3));e=(e+e.T)/2;e*=rng.uniform(1e-6,8e-4)/np.linalg.norm(e)
        q,_=np.linalg.qr(rng.normal(size=(3,3)))
        if np.linalg.det(q)<0:q[:,0]*=-1
        gradients.append(q@(eye+e)-eye)
    g=torch.tensor(np.stack(gradients),dtype=torch.float64);full,e,j=piola(g,learned,'murnaghan');truth,_,_=piola(g,nominal,'murnaghan');stvk,_,_=piola(g,nominal,'stvk');increment=full-stvk;actual=truth-stvk
    material_errors=torch.linalg.matrix_norm(increment-actual,dim=(-2,-1))/torch.linalg.matrix_norm(actual,dim=(-2,-1));full_errors=torch.linalg.matrix_norm(full-truth,dim=(-2,-1))/torch.linalg.matrix_norm(truth,dim=(-2,-1))
    lowest=float('inf')
    for k in range(0,1024,32):
        tangent=torch.autograd.functional.jacobian(lambda value:piola(value,learned,'murnaghan')[0],g[k]).numpy()
        for _ in range(8):
            direction=rng.normal(size=3);direction/=np.linalg.norm(direction);acoustic=np.einsum('iajb,a,b->ij',tangent,direction,direction);np.testing.assert_allclose(acoustic,acoustic.T,rtol=1e-12,atol=1e-4);lowest=min(lowest,float(np.linalg.eigvalsh(acoustic).min()))
    result={'schema':'workai.learned_energy_orientation_check.v1','checkpoint_sha256':model['checkpoint_sha256'],'source_sha256':digest(Path(__file__)),'seed':2026102379,'independent_synthetic_strain_states':1024,'rotations_applied':True,'sampled_acoustic_tensors':256,'full_piola_max_relative_error':float(full_errors.max()),'material_piola_max_relative_error':float(material_errors.max()),'max_Green_strain':float(torch.linalg.matrix_norm(e,dim=(-2,-1)).max()),'min_J':float(j.min()),'minimum_sampled_acoustic_eigenvalue_pa':lowest,'passed':bool(material_errors.max()<.05 and full_errors.max()<.05 and lowest>0 and j.min()>0),'extends_transient_acceptance':False,'scope':'Synthetic local material-law orientation and sampled ellipticity verification; not experimental validation or a global guarantee.'}
    with a.output.open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())

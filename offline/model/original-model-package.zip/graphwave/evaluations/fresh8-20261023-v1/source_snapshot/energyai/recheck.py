"""Recompute published errors from frozen field bytes, without new optimization."""
import argparse,gc,json
from pathlib import Path
import numpy as np
from spectral3d.compare import spectral,compare,digest
from spectral3d.field_compare import field,weighted


def main(a):
    metrics=json.loads((a.evaluation/'metrics.json').read_text());rows=[]
    for row in metrics['cases']:
        prediction=Path(row['prediction_manifest']);reference=Path(row['reference_manifest'])
        assert digest(prediction)==row['prediction_manifest_sha256'] and digest(reference)==row['reference_manifest_sha256']
        pm=json.loads(prediction.read_text());tm=json.loads(reference.read_text());p=pm['cases'][0];t=tm['cases'][0]
        assert p['case_id']==t['case_id']==row['case_id'] and p['scene']==t['scene']==row['scene']
        assert pm['reference_responses_read_for_inference'] is False and pm['model']['checkpoint_sha256']==metrics['checkpoint_sha256']
        trace=compare(spectral(prediction),spectral(reference))['cases'][0]
        assert trace['all_probe_checks_pass']==row['probe_checks_pass']
        for new,old in zip(trace['probes'],row['probes']):assert new['checks']==old['checks']
        for directory,manifest in [(prediction.parent,pm),(reference.parent,tm)]:
            for name,sha in manifest['source_sha256'].items():assert digest(directory/'source_snapshot'/name)==sha
        with np.load(prediction.parent/p['mesh_file'],allow_pickle=False) as saved:mass=saved['mass']
        predicted=[field(prediction.parent,p,law) for law in ['linear','stvk','murnaghan']];truth=[field(reference.parent,t,law) for law in ['linear','stvk','murnaghan']]
        for name,v,w in [('full',predicted[2],truth[2]),('material',predicted[2]-predicted[1],truth[2]-truth[1]),('geometric',predicted[1]-predicted[0],truth[1]-truth[0])]:
            assert weighted(v,w,mass)==row['field_checks'][name+'_vector']
            for axis,label in enumerate('xyz'):assert weighted(v[:,:,axis:axis+1],w[:,:,axis:axis+1],mass)==row['field_checks'][name+'_'+label]
        rows.append({'case_id':row['case_id'],'field_and_probe_metrics_recomputed':True,'prediction_and_reference_source_hashes_verified':True});del predicted,truth;gc.collect()
    result={'schema':'workai.learned_energy_independent_recheck.v1','metrics_sha256':digest(a.evaluation/'metrics.json'),'checkpoint_sha256':metrics['checkpoint_sha256'],'all_passed':len(rows)==8,'cases':rows,'new_training_or_solves':0}
    with (a.evaluation/'independent-recheck.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--evaluation',type=Path,required=True);main(p.parse_args())

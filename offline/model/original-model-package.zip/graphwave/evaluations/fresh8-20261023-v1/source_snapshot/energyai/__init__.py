"""Objective learned material energy with full-space physical propagation."""

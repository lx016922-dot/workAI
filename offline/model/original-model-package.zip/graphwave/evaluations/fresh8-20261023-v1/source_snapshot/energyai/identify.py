"""Learn cubic aluminum energy from wave fields and weak momentum.

The three unknown TOECs are never supplied as regression targets. Linear
elasticity is fixed; observed full/StVK displacement differences provide the
inverse-dynamics target. This is a learned-material numerical model, not a
one-shot neural wave operator or experimental material characterization.
"""
import argparse,json,shutil,time
from pathlib import Path
import numpy as np
import torch
from operator3d.physics import U0,T0,piola
from operator3d.train import atomic,now
from spectralop.data import load_dataset,digest
from spectralop.physics import star,choose_targets

SCALE=1e11


def basis(gradient):
    eye=torch.eye(3,dtype=gradient.dtype);f=eye+gradient;e=.5*(gradient+gradient.transpose(-1,-2)+gradient.transpose(-1,-2)@gradient)
    e2=e@e;tr=e.diagonal(dim1=-2,dim2=-1).sum(-1);tr2=e2.diagonal(dim1=-2,dim2=-1).sum(-1)
    ll=tr[...,None,None]**2*eye
    mm=tr2[...,None,None]*eye+2*tr[...,None,None]*e-ll
    nn=e2-.5*tr2[...,None,None]*eye-tr[...,None,None]*e+.5*ll
    return torch.stack([f@ll,f@mm,f@nn],-1)*SCALE


def equations(case,frames,targets):
    patch=star(case,targets);nodes=patch['ids'].numpy();cells=patch['cells'];grad=patch['grad'];weight=patch['weights'];at=patch['at'];mass=case['mass'][patch['targets']];dt=case['times'][1]-case['times'][0];mat=case['scene']['material'];rows=[];rhs=[]
    # The original l/m/n metadata is not used in this linear-elastic/StVK path.
    linear_material={**mat,'l_pa':0.,'m_pa':0.,'n_pa':0.}
    for frame in frames:
        pieces=torch.as_tensor(case['parts'][frame,nodes],dtype=torch.float64)*U0
        full=pieces.sum(1);geometric=pieces[:,:2].sum(1)
        gu=torch.einsum('eai,eqaj->eqij',full[cells],grad);gg=torch.einsum('eai,eqaj->eqij',geometric[cells],grad)
        pu,_,_=piola(gu,linear_material,'stvk');pg,_,_=piola(gg,linear_material,'stvk')
        local=torch.einsum('eqij,eqaj,eq->eai',pu-pg,grad,weight)
        difference=torch.zeros((len(nodes),3),dtype=torch.float64).index_add(0,cells.flatten(),local.reshape(-1,3))[at]
        local_basis=torch.einsum('eqijk,eqaj,eq->eaik',basis(gu),grad,weight)
        force=torch.zeros((len(nodes),3,3),dtype=torch.float64).index_add(0,cells.flatten(),local_basis.reshape(-1,3,3))[at]
        # Fourth-order central acceleration of the observed material increment.
        values=torch.as_tensor(case['parts'][frame-2:frame+3,nodes,2],dtype=torch.float64)*U0
        acceleration=(-values[4]+16*values[3]-30*values[2]+16*values[1]-values[0])[at]/(12*(dt*T0)**2)
        target=-mass[:,None]*acceleration-difference
        rows.append(force.reshape(-1,3).numpy());rhs.append(target.flatten().numpy())
    matrix=np.concatenate(rows);target=np.concatenate(rhs);normal=max(float(np.sqrt(np.mean(target**2))),1e-20)
    return matrix/normal,target/normal,normal


def run(args):
    out=args.output;out.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);torch.manual_seed(2026102343);rng=np.random.default_rng(2026102343);started=time.monotonic();repo=Path(__file__).resolve().parents[1];hashes={}
    for module in ['energyai','spectralop','spectral3d','operator3d','solid']:
        target=out/'source_snapshot'/module;target.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,target/path.name);hashes[module+'/'+path.name]=digest(path)
    cases,_,data=load_dataset(args.dataset,admission_path=args.admission);atomic(out/'source-dataset.json',data)
    arrays={};records=[]
    for case in cases:
        frames=np.unique(np.linspace(18,len(case['times'])-4,28,dtype=int));targets=choose_targets(case,rng,count=20)
        with torch.no_grad():a,b,normal=equations(case,frames,targets)
        arrays[case['case_id']+'_matrix']=a;arrays[case['case_id']+'_target']=b
        records.append({'case_id':case['case_id'],'split':case['split'],'frames':frames.tolist(),'targets':targets.tolist(),'normalization_force_N':normal,'rows':len(b)})
        print(json.dumps({'prepared':case['case_id'],'equations':len(b)}),flush=True)
    np.savez_compressed(out/'weak-equations.npz',**arrays);atomic(out/'sampling.json',records)
    train=[c for c in records if c['split']=='train'];valid=[c for c in records if c['split']=='validation']
    a=np.concatenate([arrays[c['case_id']+'_matrix']/np.sqrt(len(arrays[c['case_id']+'_target'])) for c in train]);b=np.concatenate([arrays[c['case_id']+'_target']/np.sqrt(len(arrays[c['case_id']+'_target'])) for c in train]);u,s,vh=np.linalg.svd(a,full_matrices=False)
    if s[-1]/s[0]<1e-6:raise ValueError('Material coefficients are not identifiable from these wave fields.')
    transform=vh.T/s;design=torch.as_tensor(a@transform,dtype=torch.float64);target=torch.as_tensor(b,dtype=torch.float64);beta=torch.nn.Parameter(torch.zeros(3,dtype=torch.float64));optimizer=torch.optim.Adam([beta],lr=.04);best=float('inf');history=[]
    config={'schema':'workai.learned_energy_fit.v1','architecture':'objective_cubic_energy_with_full_space_propagation','trainable_parameters':3,'steps':2000,'train_cases':len(train),'validation_cases':len(valid),'unknown_parameter_order':['l','m','n'],'parameter_scale_pa':SCALE,'unknown_constants_used_as_targets':False,'linear_constants_known':True,'whitening_from_training_only':True,'design_condition_number':float(s[0]/s[-1]),'wave_acceleration':'five_point_fourth_order_dt_0.05_us','source_sha256':hashes,'equations_sha256':digest(out/'weak-equations.npz'),'test_fields_loaded':False,'pure_neural_transient_operator':False,'scope':'Identification from synthetic validated wave fields, not independent experimental characterization.'};atomic(out/'config.json',config)
    def losses(theta,rows):return {c['case_id']:float(np.mean((arrays[c['case_id']+'_matrix']@theta-arrays[c['case_id']+'_target'])**2)) for c in rows}
    for step in range(1,2001):
        prediction=design@beta;loss=(prediction-target).square().sum()/len(train);optimizer.zero_grad();loss.backward();optimizer.step()
        if step==1 or step%20==0:
            theta=transform@beta.detach().numpy();training=losses(theta,train);validation=losses(theta,valid);val=float(np.mean(list(validation.values())));selected=val<best
            checkpoint={'step':step,'beta':beta.detach().clone(),'transform':torch.as_tensor(transform),'constants_pa':torch.as_tensor(theta*SCALE),'optimizer_state':optimizer.state_dict(),'equations_sha256':config['equations_sha256']};torch.save(checkpoint,out/'last.pt')
            if selected:best=val;torch.save(checkpoint,out/'best.pt')
            row={'step':step,'train_relative_rms':float(np.sqrt(np.mean(list(training.values())))),'validation_relative_rms':float(np.sqrt(val)),'constants_pa':(theta*SCALE).tolist(),'selected':selected};history.append(row)
    chosen=torch.load(out/'best.pt',map_location='cpu',weights_only=True);atomic(out/'history.json',history)
    receipt={'schema':'workai.learned_energy_weights.v1','run_id':out.name,'status':'trained_pending_fresh_tests','step':2000,'selected_step':chosen['step'],'constants_pa':chosen['constants_pa'].tolist(),'checkpoint_sha256':digest(out/'best.pt'),'equations_sha256':config['equations_sha256'],'frozen_at_utc':now(),'final_test_fields_loaded':False,'design_condition_number':config['design_condition_number'],'train_relative_residuals':losses(chosen['constants_pa'].numpy()/SCALE,train),'validation_relative_residuals':losses(chosen['constants_pa'].numpy()/SCALE,valid),'elapsed_s':time.monotonic()-started,'pure_neural_transient_operator':False,'accepted_for_solver_routing':False};atomic(out/'weights.json',receipt);print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--dataset',type=Path,required=True);parser.add_argument('--admission',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);run(parser.parse_args())

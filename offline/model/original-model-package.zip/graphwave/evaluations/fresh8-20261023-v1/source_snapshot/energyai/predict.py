"""Three independent physical controls using one frozen learned energy law.

Inputs contain geometry/excitation, discretization and model identity only.
No reference displacement, test response or fitted geometric mode is read.
"""
import argparse,copy,json,shutil
from pathlib import Path
import numpy as np
from solid.schema import validate_scene
from spectral3d.mesh import make_mesh
from spectral3d.solver import solve
from spectral3d.campaign import atomic,now
from spectral3d.compare import digest
from .model import load_model,effective_material


def run(args):
    request=json.loads(args.input.read_text());scene=validate_scene(request['scene']);model=load_model(args.model)
    assert request['checkpoint_sha256']==model['checkpoint_sha256'];root=args.output;root.mkdir(parents=True,exist_ok=False);repo=Path(__file__).resolve().parents[1];hashes={}
    for module in ['energyai','solid','spectral3d']:
        dest=root/'source_snapshot'/module;dest.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,dest/path.name);hashes[module+'/'+path.name]=digest(path)
    mesh=make_mesh(scene,request['degree'],request['h_mm']);cid=request['case_id'];np.savez_compressed(root/(cid+'-mesh.npz'),**mesh)
    row={'case_id':cid,'scene':scene,'phase':'running','controls':[],'mesh_file':cid+'-mesh.npz','mesh_sha256':digest(root/(cid+'-mesh.npz'))}
    manifest={'schema':'workai.learned_energy_prediction.v1','phase':'running','created_at_utc':now(),'source_sha256':hashes,'input_sha256':digest(args.input),'cases':[row],
              'model':{'checkpoint_sha256':model['checkpoint_sha256'],'weights_manifest_sha256':model['weights_manifest_sha256'],'constants_pa':model['constants_pa'],'architecture':'learned_objective_cubic_energy_full_space_physical_dynamics'},
              'degree':request['degree'],'h_mm':request['h_mm'],'cfl':request['cfl'],'integrator':request['integrator'],'substeps':request['substeps'],
              'reference_responses_read_for_inference':False,'pure_neural_transient_operator':False,'accepted_for_solver_routing':False};atomic(root/'manifest.json',manifest)
    prepared=None
    if request['integrator']=='newmark':
        from spectral3d.implicit import prepare
        prepared=prepare(scene,mesh,request['substeps'])
    for law in ['linear','stvk','murnaghan']:
        current=copy.deepcopy(scene);current['constitutive']=law
        if law=='murnaghan':current['material']=effective_material(current['material'],model)
        directory=root/(cid+'-'+law);directory.mkdir();atomic(directory/'scene.json',current)
        control={'law':law,'directory':directory.name,'phase':'running','started_at_utc':now()};row['controls'].append(control);atomic(root/'manifest.json',manifest)
        def callback(progress):atomic(directory/'status.json',{'phase':'running',**progress})
        try:
            if request['integrator']=='newmark':
                from spectral3d.implicit import solve as implicit
                result=implicit(current,mesh,request['substeps'],True,callback,prepared)
            else:result=solve(current,mesh,request['cfl'],True,callback)
            fields=result.pop('fields_m');diagnostics=result.pop('diagnostics');np.savez_compressed(directory/'field.npz',displacement_m=fields);np.savez_compressed(directory/'probes.npz',**result);atomic(directory/'diagnostics.json',diagnostics)
            control.update(phase='completed',field_sha256=digest(directory/'field.npz'),probes_sha256=digest(directory/'probes.npz'),diagnostics_sha256=digest(directory/'diagnostics.json'),scene_sha256=digest(directory/'scene.json'));atomic(directory/'status.json',control);atomic(root/'manifest.json',manifest)
        except BaseException as error:control.update(phase='failed',error=str(error));manifest['phase']='failed';atomic(root/'manifest.json',manifest);raise
    row['phase']='completed';manifest.update(phase='completed',completed_at_utc=now());atomic(root/'manifest.json',manifest);print(json.dumps({'case_id':cid,'completed':True,'controls':3,'checkpoint_sha256':model['checkpoint_sha256']}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True);parser.add_argument('--model',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);run(parser.parse_args())

"""Bind immutable trained weights to independently evaluated use, without retraining."""
import argparse,json,re
from pathlib import Path
import numpy as np
from spectral3d.compare import digest,spectral
from .model import load_model

GATES=['fresh_test_geometries','reference_h_p_time_full_fields','full_field_and_components','receivers_and_material_2f','all_node_sampled_time_physics','energy_strain_positive_J','exact_initial_and_fixed']


def load_release(root):
    root=Path(root);record=json.loads((root/'energyai/latest.json').read_text())
    if record['schema']!='workai.learned_energy_release.v1' or not all(re.fullmatch(r'[a-zA-Z0-9-]{1,100}',record[k]) for k in ['run_id','evaluation_id']):raise ValueError('Material release identity mismatch.')
    model=load_model(root/'energyai/runs'/record['run_id']);path=root/'energyai/evaluations'/record['evaluation_id']/'metrics.json';metrics=json.loads(path.read_text())
    if digest(path)!=record['metrics_sha256'] or model['checkpoint_sha256']!=record['checkpoint_sha256'] or model['weights_manifest_sha256']!=record['weights_manifest_sha256'] or metrics['constants_pa']!=model['constants_pa'] or metrics['weights_manifest_sha256']!=model['weights_manifest_sha256'] or metrics['checkpoint_sha256']!=model['checkpoint_sha256']:raise ValueError('Material release hash mismatch.')
    if not all(metrics['acceptance'][k] is True for k in GATES+['all_gates_passed']) or metrics['acceptance']['threshold']!=.05 or metrics['test_used_for_checkpoint_selection'] is not False or metrics['pure_neural_transient_operator'] is not False or metrics['accepted_for_solver_routing'] is not False or metrics['accepted_for_learned_material_use'] is not True or record['accepted_for_learned_material_use'] is not True:raise ValueError('Material model has not passed independent evaluation.')
    return record,model


def main(args):
    import torch
    model=load_model(args.model);metrics=json.loads((args.evaluation/'metrics.json').read_text());plan=json.loads((args.evaluation/'plan.json').read_text())
    assert metrics['checkpoint_sha256']==model['checkpoint_sha256'] and metrics['weights_manifest_sha256']==model['weights_manifest_sha256'] and metrics['constants_pa']==model['constants_pa']
    for name,sha in plan['evaluation_source_sha256'].items():assert digest(args.evaluation/'source_snapshot'/name)==sha
    # The JSON coefficients must be identical to the selected actual optimizer checkpoint.
    checkpoint=torch.load(args.model/'best.pt',map_location='cpu',weights_only=True)
    assert checkpoint['step']==model['selected_step'] and checkpoint['constants_pa'].tolist()==model['constants_pa'] and checkpoint['equations_sha256']==model['equations_sha256']
    np.testing.assert_allclose((checkpoint['transform']@checkpoint['beta']).numpy()*1e11,model['constants_pa'],rtol=1e-14,atol=.01)
    assert metrics['test_used_for_checkpoint_selection'] is False
    assert len(metrics['cases'])==8 and len({c['case_id'] for c in metrics['cases']})==8
    for row in metrics['cases']:
        for key in ['prediction_manifest','reference_manifest']:
            path=Path(row[key]);assert digest(path)==row[key+'_sha256'];spectral(path)
    assert digest(args.evaluation/'probe-predictions.npz')==metrics['probe_archive_sha256']
    assert args.model.parent.parent==args.root/'energyai' and args.evaluation.parent.parent==args.root/'energyai'
    record={'schema':'workai.learned_energy_release.v1','run_id':args.model.name,'evaluation_id':args.evaluation.name,'checkpoint_sha256':model['checkpoint_sha256'],'weights_manifest_sha256':model['weights_manifest_sha256'],'metrics_sha256':digest(args.evaluation/'metrics.json'),'accepted_for_learned_material_use':metrics['accepted_for_learned_material_use'],'accepted_for_solver_routing':False,'pure_neural_transient_operator':False}
    with (args.root/'energyai/latest.json').open('x') as f:json.dump(record,f,indent=2)
    print(json.dumps(record))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',required=True,type=Path);p.add_argument('--evaluation',required=True,type=Path);p.add_argument('--root',required=True,type=Path);main(p.parse_args())

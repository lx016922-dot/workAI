"""Post-freeze, independent eight-geometry reference campaign for GraphWave."""
import argparse,json,os,shutil,subprocess,sys,threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from spectral3d.dataset import plan
from spectral3d.compare import spectral,compare,digest
from spectral3d.field_compare import compare_fields
from spectral3d.campaign import atomic,now
from operator3d.campaign import geometry_identity


def run(args):
    freeze=json.loads((args.model/'checkpoint-freeze.json').read_text())
    assert digest(args.model/'best.pt')==freeze['checkpoint_sha256']
    assert digest(args.model/'weights.npz')==freeze['weights_sha256'] and freeze['fresh_test_fields_loaded'] is False
    root=args.output;root.mkdir(parents=True,exist_ok=False);repo=Path(__file__).resolve().parents[1];hashes={}
    for module in ['solid','spectral3d','operator3d','graphwave']:
        dest=root/'source_snapshot'/module;dest.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,dest/path.name);hashes[module+'/'+path.name]=digest(path)
    development=json.loads((args.model/'dataset.json').read_text());old={c['geometry_group_sha256'] for c in development['cases']}
    for path in [Path('/workspace/workai-remote/modal3d/campaigns/holdout64-20261023/manifest.json'),Path('/workspace/workai-remote/spectralop/retraining/references/aluminum-neural-20261023-v2/manifest.json')]:
        old.update(geometry_identity(c['scene']) for c in json.loads(path.read_text())['cases'])
    for path in Path('/workspace/workai-remote/spectral3d/jobs').glob('*/scene.json'):old.add(geometry_identity(json.loads(path.read_text())))
    cases=[]
    for c in plan(seed=args.seed)['cases']:
        if int(c['case_id'].rsplit('-',1)[-1]) not in [0,3]:continue
        kind=c['scene']['geometry']['kind'];variant='free' if c['scene']['boundary']['fixed_face']=='none' else 'fixed';cid='graphwave-test-'+kind+'-'+variant
        c.update(case_id=cid,split='test',phase='planned');c['scene']['name']=cid;c['geometry_group_sha256']=geometry_identity(c['scene']);assert c['geometry_group_sha256'] not in old;cases.append(c)
    assert len(cases)==8 and len({c['geometry_group_sha256'] for c in cases})==8
    atomic(root/'planned-inputs.json',{'schema':'workai.graphwave_fresh_inputs.v1','seed':args.seed,'created_at_utc':now(),'checkpoint_sha256':freeze['checkpoint_sha256'],
        'weights_sha256':freeze['weights_sha256'],'checkpoint_freeze_sha256':digest(args.model/'checkpoint-freeze.json'),'cases':cases,'excluded_prior_geometry_count':len(old),
        'test_scope':'Eight new geometries generated after selection and freeze. No test response is used for fitting or choosing weights.'})
    manifest={'schema':'workai.graphwave_references.v1','phase':'running','created_at_utc':now(),'planned_inputs_sha256':digest(root/'planned-inputs.json'),'source_sha256':hashes,
        'frozen_checkpoint_sha256':freeze['checkpoint_sha256'],'frozen_weights_sha256':freeze['weights_sha256'],'threshold':.05,
        'rule':'p4/h1.4 for plate/pipe/notch and p4/h2 for hole; h,p,time,whole-field checks retain 5%/1e-13m thresholds. Reference-only fallback to h1.4 for holes, then h1. No prediction used in reference admission.',
        'cases':[{'case_id':c['case_id'],'scene':c['scene'],'phase':'waiting'} for c in cases]};lock=threading.RLock()
    def publish():
        with lock:manifest['updated_at_utc']=now();atomic(root/'manifest.json',manifest)
    def solve(case,p,h,cfl=.3,substeps=4,fields=True):
        label=f'p{p}-h{h:g}-cfl{cfl:g}-sub{substeps}';path=root/case['case_id']/label
        if path.exists():
            existing=path/'manifest.json';assert json.loads(existing.read_text())['phase']=='completed';spectral(existing);return existing
        cmd=[sys.executable,'-m','spectral3d.campaign','--campaign',str(root/'planned-inputs.json'),'--output',str(path),'--cases',case['case_id'],'--degree',str(p),'--h',str(h),'--cfl',str(cfl),'--substeps',str(substeps),'--integrator','newmark' if case['scene']['geometry']['kind']=='hole' else 'verlet']
        if fields:cmd.append('--fields')
        with (path.parent/(label+'.log')).open('x') as log:subprocess.run(cmd,cwd=root/'source_snapshot',env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
        return path/'manifest.json'
    def check(paths,dest):
        baseline=spectral(paths['base']);q={k:compare(baseline,spectral(paths[k])) for k in ['space','degree','time']};q['field']=compare_fields(paths['base'],paths['space']);q['levels']={k:{'manifest':str(v),'sha256':digest(v)} for k,v in paths.items()}
        q['guards_passed']=all(d['energy_balance_within_1_percent'] and d['max_strain']<=.001 and d['min_J']>0 for p in paths.values() for c in spectral(p).values() for d in c['diagnostics'])
        q['passed']=q['guards_passed'] and q['field']['all_checks_pass'] and all(q[k]['all_probe_checks_pass'] for k in ['space','degree','time']);atomic(dest,q);return q['passed']
    def work(pair):
        case,row=pair;directory=root/case['case_id'];directory.mkdir()
        try:
            candidates=[2.,1.4,1.] if case['scene']['geometry']['kind']=='hole' else [1.4,1.]
            row['attempts']=[]
            for h in candidates:
                row.update(phase='solving',current_h_mm=h);publish();fine={2.:1.4,1.4:1.,1.:.75}[h]
                paths={'base':solve(case,4,h),'space':solve(case,4,fine),'degree':solve(case,5,h,fields=False),'time':solve(case,4,h,.15,8,False)}
                quality=directory/f'quality-h{h:g}.json';passed=check(paths,quality);row['attempts'].append({'quality_path':str(quality),'sha256':digest(quality),'passed':passed})
                publish()
                if passed:break
            row.update(phase='completed',reference_checks_passed=passed,base_manifest=str(paths['base']),base_manifest_sha256=digest(paths['base']),quality_path=str(quality),quality_sha256=digest(quality),levels={k:{'manifest':str(v),'sha256':digest(v)} for k,v in paths.items()});publish()
            print(json.dumps({'case_id':case['case_id'],'reference_checks_passed':passed}),flush=True)
        except BaseException as error:row.update(phase='failed',reference_checks_passed=False,error=str(error));publish();print(json.dumps({'case_id':case['case_id'],'error':str(error)}),flush=True)
    publish()
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(work,zip(cases,manifest['cases'])))
    manifest.update(phase='completed',all_reference_checks_passed=all(c.get('reference_checks_passed',False) for c in manifest['cases']),completed_at_utc=now());publish()
    if not manifest['all_reference_checks_passed']:raise ValueError('Fresh reference quality failed; cannot accept neural predictions.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--seed',type=int,default=2026102403);run(p.parse_args())

"""Evaluate frozen neural inference as qualified independent references finish."""
import argparse,json,os,shutil,subprocess,time,gc
from pathlib import Path
import numpy as np
import torch
from .evaluate import evaluate_case
from spectral3d.compare import digest,spectral
from operator3d.train import atomic,now
from operator3d.campaign import geometry_identity


def run(args):
    args.output.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);started=time.monotonic()
    freeze=json.loads((args.model/'checkpoint-freeze.json').read_text());checkpoint=freeze['checkpoint_sha256'];weights=freeze['weights_sha256']
    assert digest(args.model/'best.pt')==checkpoint and digest(args.model/'weights.npz')==weights
    for name,sha in freeze['inference_source_sha256'].items():assert digest(args.model/'inference_source_snapshot'/name)==sha
    dataset=json.loads((args.model/'dataset.json').read_text());old={c['geometry_group_sha256'] for c in dataset['cases']}
    inputs=args.references.parent/'planned-inputs.json'
    while not inputs.exists():time.sleep(2)
    plan=json.loads(inputs.read_text());assert plan['checkpoint_sha256']==checkpoint and plan['weights_sha256']==weights
    assert plan['created_at_utc']>freeze['frozen_at_utc'];assert len(plan['cases'])==8
    groups=[geometry_identity(c['scene']) for c in plan['cases']];assert len(set(groups))==8 and not old.intersection(groups)
    sources={};repo=Path(__file__).resolve().parents[1]
    for module in ['graphwave','spectralop','operator3d','spectral3d','energyai','solid']:
        dest=args.output/'source_snapshot'/module;dest.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,dest/path.name);sources[module+'/'+path.name]=digest(path)
    atomic(args.output/'plan.json',{'schema':'workai.graphwave_evaluation_plan.v1','checkpoint_sha256':checkpoint,'weights_sha256':weights,'input_plan_sha256':digest(inputs),'threshold':.05,
        'reporting_floor_m':1e-13,'test_geometries':8,'test_used_for_weight_selection':False,'evaluation_source_sha256':sources,
        'physical_checks':'All free nodes at nine predefined output frames; full/XYZ/material/geometric fields, all-node complex 2f, probe XYZ/requested-direction waveforms and complex 2f, energy, strain, J.'})
    status=json.loads((args.model/'status.json').read_text());rows=[]
    def publish(phase,**extra):
        status.update(status=phase,updated_at_utc=now(),elapsed_s=time.monotonic()-started,evaluation_id=args.output.name,test_cases_completed=len(rows),test_cases_total=8,**extra)
        atomic(args.model/'status.json',status);atomic(args.model.parents[1]/'latest.json',status);atomic(args.output/'status.json',status)
    publish('evaluating_fresh_tests')
    while len(rows)<8:
        references=json.loads(args.references.read_text());assert references['planned_inputs_sha256']==digest(inputs)
        available=[c for c in references['cases'] if c.get('reference_checks_passed') and c['case_id'] not in {r['case_id'] for r in rows}]
        if not available:
            if references['phase']=='completed':raise ValueError('One or more independent references failed their original gates.')
            publish('waiting_for_references');time.sleep(10);continue
        item=available[0];cid=item['case_id'];quality_path=Path(item['quality_path']);assert digest(quality_path)==item['quality_sha256'];quality=json.loads(quality_path.read_text())
        assert quality['passed'] and quality['guards_passed'] and quality['field']['all_checks_pass'] and all(quality[k]['all_probe_checks_pass'] for k in ['space','degree','time'])
        for level in item['levels'].values():assert digest(Path(level['manifest']))==level['sha256'];spectral(Path(level['manifest']))
        base=json.loads(Path(item['base_manifest']).read_text());request={'case_id':cid,'scene':item['scene'],'degree':base['degree'],'h_mm':base['h_mm'],'cfl':.3,'weights_sha256':weights}
        path=args.output/(cid+'-input.json');atomic(path,request);publish('predicting',current_case=cid)
        command=['/workspace/workai-remote/solid/venv/bin/python','-m','graphwave.predict','--input',str(path),'--weights',str(args.model/'weights.npz'),'--output',str(args.output/cid)]
        with (args.output/(cid+'.log')).open('x') as stream:subprocess.run(command,cwd=args.model/'inference_source_snapshot',env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=stream,stderr=subprocess.STDOUT,check=True)
        publish('checking_predictions',current_case=cid);row=evaluate_case(item,args.output/cid,dataset['branch_scales_in_100nm']);row.update(reference_checks_passed=True,reference_quality_sha256=item['quality_sha256'],reference_quality_path=item['quality_path'],scene=item['scene'])
        rows.append(row);atomic(args.output/(cid+'-metrics.json'),row);atomic(args.output/'partial-results.json',rows)
        print(json.dumps({'case_id':cid,'full_relative_l2':row['field_checks']['full_vector']['relative_l2'],'material_relative_l2':row['field_checks']['material_vector']['relative_l2'],
            'all_gates_passed':row['all_gates_passed'],'reference_checks_passed':True,'evaluated':len(rows)}),flush=True);gc.collect();publish('evaluating_fresh_tests')
    assert digest(args.model/'best.pt')==checkpoint and digest(args.model/'weights.npz')==weights
    references=json.loads(args.references.read_text());assert references['phase']=='completed' and references['all_reference_checks_passed']
    gates={'fresh_test_geometries':len(rows)==8,'reference_h_p_time_full_fields':all(r['reference_checks_passed'] for r in rows),
        'full_material_geometric_fields_and_components':all(c['pass'] for r in rows for c in r['field_checks'].values()),
        'receivers_and_material_2f':all(r['probe_checks_pass'] for r in rows),'all_node_sampled_time_physics':all(r['physical_checks']['passed'] for r in rows),
        'energy_strain_positive_J':all(r['energy_strain_J_pass'] for r in rows),'exact_initial_and_fixed':all(r['exact_initial_and_fixed'] for r in rows)}
    metrics={'schema':'workai.graphwave_metrics.v1','checkpoint_sha256':checkpoint,'weights_sha256':weights,'reference_manifest_sha256':digest(args.references),
        'test_geometries_created_after_freeze':True,'test_used_for_weight_selection':False,'cases':rows,'acceptance':{'threshold':.05,**gates,'all_gates_passed':all(gates.values())},
        'neural_forward_only':True,'numerical_correction':False,'spatially_discretized_recurrent_network':True,'accepted_for_solver_routing':False,
        'scope':'Fixed sourced aluminum law, four parameterized geometry families, 8–12 mm length, .18–.28 MHz, .6–1.5 MPa, 14 us. Eight synthetic held-out cases are not a guarantee for every point/direction, arbitrary CAD, other alloys or longer times.',
        'completed_at_utc':now()};atomic(args.output/'metrics.json',metrics)
    publish('completed_accepted' if all(gates.values()) else 'completed_failed_gates',metrics_sha256=digest(args.output/'metrics.json'),all_gates_passed=all(gates.values()))
    print(json.dumps({'completed':True,'acceptance':metrics['acceptance']}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--references',type=Path,required=True);p.add_argument('--output',type=Path,required=True);run(p.parse_args())

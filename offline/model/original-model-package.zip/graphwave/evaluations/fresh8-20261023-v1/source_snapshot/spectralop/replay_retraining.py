"""Independent mass-integral and complex-probe replay, plus exact model reload."""
import argparse,json
from pathlib import Path
import numpy as np
import torch
from .retraining_data import reference_case
from .normalized_model import NormalizedWaveField
from .data import digest
from operator3d.propagation_model import PropagationSeparatedField
from operator3d.train import predict_case
from operator3d.physics import U0


def run(a):
    torch.set_num_threads(2);summary=json.loads((a.evaluation/'summary.json').read_text());freeze=json.loads((a.model/'checkpoint-freeze.json').read_text());config=json.loads((a.model/'config.json').read_text())
    assert digest(a.model/'best.pt')==summary['checkpoint_sha256']==freeze['checkpoint_sha256'] and freeze['fresh_test_fields_loaded'] is False
    assert digest(a.model/'dataset.json')==config['dataset_sha256'];assert digest(a.references)==summary['reference_manifest_sha256']
    for name,sha in config['source_sha256'].items():assert digest(a.model/'source_snapshot'/name)==sha
    for name,sha in json.loads((a.evaluation/'evaluation-source.json').read_text()).items():assert digest(a.evaluation/'source_snapshot'/name)==sha
    references=json.loads(a.references.read_text());development=json.loads((a.model/'dataset.json').read_text());used={c['geometry_group_sha256'] for c in development['cases']};rows=[]
    for kind,model_root in [('retrained',a.model),('previous',a.previous)]:
        root=a.evaluation/kind;metrics=json.loads((root/'metrics.json').read_text());assert digest(model_root/'best.pt')==metrics['checkpoint_sha256'];assert digest(root/'probe-predictions.npz')==metrics['probe_archive_sha256']
        saved=torch.load(model_root/'best.pt',map_location='cpu',weights_only=True)
        model=NormalizedWaveField(saved['unit_scales'],saved['context_mean'],saved['context_std'],saved['width']) if kind=='retrained' else PropagationSeparatedField(saved['scales'],saved['width']);model.load_state_dict(saved['model_state'])
        with np.load(root/'probe-predictions.npz',allow_pickle=False) as probes:
            for index,item in enumerate(references['cases']):
                case,_=reference_case(item,'test');assert case['group'] not in used;row=next(c for c in metrics['cases'] if c['case_id']==case['case_id']);path=root/(case['case_id']+'-prediction.npz');assert digest(path)==row['prediction_archive_sha256']
                with np.load(path,allow_pickle=False) as archive:pred=archive['parts_m'];np.testing.assert_array_equal(archive['times_us'],case['times'])
                truth=case['parts']*U0;mass=case['mass'].numpy()[None,:,None];assert np.isfinite(pred).all();assert np.all(pred[0]==0);assert np.all(pred[:,case['fixed'].numpy()]==0)
                count=0
                for name,p,t in [('full',pred.sum(2),truth.sum(2)),('geometric',pred[:,:,1],truth[:,:,1]),('material',pred[:,:,2],truth[:,:,2])]:
                    for axis,label in [(None,'vector'),(0,'x'),(1,'y'),(2,'z')]:
                        aa=p if axis is None else p[:,:,axis:axis+1];bb=t if axis is None else t[:,:,axis:axis+1];m=row['field_checks'][name+'_'+label]
                        difference=float(np.sqrt(np.sum(mass*(aa-bb)**2)/(mass.sum()*len(aa)*aa.shape[2])));reference=float(np.sqrt(np.sum(mass*bb**2)/(mass.sum()*len(bb)*bb.shape[2])))
                        np.testing.assert_allclose([difference*1e9,reference*1e9],[m['difference_rms_nm'],m['finer_rms_nm']],rtol=2e-12,atol=1e-14)
                        if reference>1e-13:np.testing.assert_allclose(difference/reference,m['relative_l2'],rtol=2e-12,atol=1e-14)
                        assert m['pass']==bool(difference/reference<=.05 if reference>1e-13 else difference<=1e-13);count+=1
                for i,(ids,weights) in enumerate(case['receivers']):
                    p=np.einsum('tnkc,n->tkc',pred[:,ids],weights);t=np.einsum('tnkc,n->tkc',truth[:,ids],weights);prefix=case['case_id']+f'_P{i+1}'
                    np.testing.assert_array_equal(p,probes[prefix+'_prediction']);np.testing.assert_array_equal(t,probes[prefix+'_fem']);metric=row['probes'][i];direction=np.array(metric['direction']);direction/=np.linalg.norm(direction);times=case['times'];window=np.hanning(len(times));frequency=2*case['scene']['source']['frequency_mhz']
                    def coefficient(v):return 2*np.sum(window*(v-window@v/window.sum())*np.exp(-2j*np.pi*frequency*times))/window.sum()
                    pc=coefficient(p[:,2]@direction);tc=coefficient(t[:,2]@direction)
                    np.testing.assert_allclose([abs(pc)*1e9,abs(tc)*1e9],[metric['material_2f_predicted_nm'],metric['material_2f_fem_nm']],rtol=2e-12,atol=1e-14)
                    if metric['material_2f_complex_relative_error'] is not None:np.testing.assert_allclose(abs(pc-tc)/abs(tc),metric['material_2f_complex_relative_error'],rtol=2e-12,atol=1e-14)
                    for key,pp,tt in [('full_waveform_relative_l2',p.sum(1)@direction,t.sum(1)@direction),('material_waveform_relative_l2',p[:,2]@direction,t[:,2]@direction)]:
                        if metric[key] is not None:np.testing.assert_allclose(np.linalg.norm(pp-tt)/np.linalg.norm(tt),metric[key],rtol=2e-12,atol=1e-14)
                if index==0:np.testing.assert_array_equal(predict_case(model,case)*U0,pred)
                rows.append({'model':kind,'case_id':case['case_id'],'field_metrics_reproduced':count,'probe_arrays_exact':True,'waveforms_and_complex_2f_reproduced':True,'initial_and_fixed_displacement_exact_zero':True,'full_field_reload_exact':index==0})
    result={'passed':True,'checkpoint_sha256':summary['checkpoint_sha256'],'training_source_snapshot_verified':True,'evaluation_source_snapshot_verified':True,'new_tests_disjoint_from_development':True,'cases':rows,'new_training_steps':0,'new_solves':0}
    with a.output.open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--previous',type=Path,required=True);p.add_argument('--evaluation',type=Path,required=True);p.add_argument('--references',type=Path,required=True);p.add_argument('--output',type=Path,required=True);run(p.parse_args())

"""A separate shared-network retraining run; never replaces accepted material weights."""
import argparse,json,math,shutil,time
from pathlib import Path
import numpy as np
import torch
from .normalized_model import NormalizedWaveField,exact_harmonics
from .retraining_data import load_development,case_rms
from .physics import physics_loss,choose_targets
from .data import digest
from operator3d.train import atomic,now,design


def tensor(x):return torch.as_tensor(x,dtype=torch.float64)


def validation(model,cases,designs,norms,scales,targets):
    rows=[]
    with torch.no_grad():
        for c in cases:
            ids,frames=designs[c['case_id']];pred=model(c,torch.as_tensor(ids),tensor(c['times'][frames]));true=tensor(c['parts'][frames,ids])
            mse=((pred-true)/norms[c['case_id']][None,:,None]).square().mean((0,2))
            a,b,_,guard=physics_loss(model,c,7.3,scales,targets[c['case_id']])
            rows.append({'case_id':c['case_id'],'branch_relative_l2':mse.sqrt().tolist(),'mean_relative_mse':float(mse.mean()),'interior':float(a),'boundary':float(b),'max_strain':float(guard['max_strain']),'min_J':float(guard['min_J'])})
    return {'relative_mse':float(np.mean([c['mean_relative_mse'] for c in rows])),'physics_mse':float(np.mean([c['interior']+c['boundary'] for c in rows])),'cases':rows}


def run(args):
    out=args.output;out.mkdir(parents=True,exist_ok=False);started=time.monotonic();torch.set_num_threads(2);torch.manual_seed(args.seed);rng=np.random.default_rng(args.seed);repo=Path(__file__).resolve().parents[1];hashes={}
    for module in ['solid','spectral3d','operator3d','spectralop']:
        dest=out/'source_snapshot'/module;dest.mkdir(parents=True)
        for p in (repo/module).glob('*.py'):shutil.copyfile(p,dest/p.name);hashes[module+'/'+p.name]=digest(p)
    latest=out.parents[1]/'latest.json';status={'schema':'workai.neural_retraining.v1','run_id':out.name,'status':'preparing','step':0,'steps_total':args.steps,'started_at_utc':now(),'accepted_for_solver_routing':False}
    def publish(**values):
        status.update(values,updated_at_utc=now(),elapsed_s=time.monotonic()-started);atomic(out/'status.json',status);atomic(latest,status)
    publish()
    try:
        cases,scale,unit,mean,std,data=load_development(args.dataset,args.admission,args.previous_tests);atomic(out/'dataset.json',data)
        train=[c for c in cases if c['split']=='train'];valid=[c for c in cases if c['split']=='validation'];scales=tensor(scale);norms={c['case_id']:case_rms(c) for c in cases}
        vrng=np.random.default_rng(args.seed+1);designs={c['case_id']:design(c,vrng,nodes=160,frames=29) for c in valid};targets={c['case_id']:choose_targets(c,vrng,count=5) for c in valid}
        atomic(out/'validation-design.json',{c['case_id']:{'nodes':designs[c['case_id']][0].tolist(),'frames':designs[c['case_id']][1].tolist(),'physics_targets':targets[c['case_id']].tolist(),'physics_time_us':7.3} for c in valid})
        model=NormalizedWaveField(unit,mean,std,args.width);optimizer=torch.optim.Adam(model.parameters(),lr=.001);best=float('inf');adaptive=.0001
        config={'schema':'workai.neural_retraining_config.v1','steps':args.steps,'seed':args.seed,'width':args.width,'architecture':'source_reflected_amplitude_normalized_three_branch_neural_field','trainable_parameters':sum(p.numel() for p in model.parameters()),'split_counts':data['split_counts'],
            'dataset_sha256':digest(out/'dataset.json'),'source_sha256':hashes,'velocity_loss_weight':.15,'harmonic_loss_weight':.2,'validation_physics_weight':.0001,
            'physics_weight_max':.002,'physics_gradient_ratio_target':.1,'physics_gradient_ratio_is_optimization_only':True,
            'quadratic_increment_scaling_is_leading_order_approximation':True,'dtype':'float64','threads':2,'checkpoint_selection':'development validation relative branch MSE + 0.0001 times fixed-node weak balance; no new test fields',
            'constraints':['Objective Murnaghan weak momentum with complete incident element stars','Loaded and traction-free boundary nodes','Exact zero initial displacement and velocity','Exact fixed-node displacement','Axial reflection covariance','First/second-order amplitude structure','Signed XYZ temporal difference and exact complex f/2f supervision','Strain <= .001 and positive J guard'],
            'fresh_tests_required_before_acceptance':True,'accepted_for_solver_routing':False};atomic(out/'config.json',config)
        baseline=validation(model,valid,designs,norms,scales,targets);atomic(out/'initial-validation.json',baseline)
        publish(status='training',split_counts=data['split_counts'],physical_case_count=len(cases),trainable_parameters=config['trainable_parameters'],validation=baseline,constraints=config['constraints'])
        families={kind:[c for c in train if c['scene']['geometry']['kind']==kind] for kind in ['plate','pipe','hole','notch']}
        for step in range(1,args.steps+1):
            data_losses=[];velocity_losses=[];harmonic=torch.zeros((),dtype=torch.float64)
            kinds=list(families);chosen=[families[kinds[(step+j)%4]][int(rng.integers(len(families[kinds[(step+j)%4]])))] for j in range(2)]
            for j,c in enumerate(chosen):
                mass=c['mass'].numpy();ids=rng.choice(len(mass),384,p=mass/mass.sum());frames=rng.integers(1,len(c['times'])-1,384);normal=norms[c['case_id']][None,:,None];times=tensor(c['times'][frames])
                pred=model(c,torch.as_tensor(ids),times);truth=tensor(c['parts'][frames,ids]);data_losses.append(((pred-truth)/normal).square().mean())
                dt=c['times'][1]-c['times'][0];selected=ids[:128];when=times[:128];freq=c['scene']['source']['frequency_mhz']
                pred_velocity=(model(c,torch.as_tensor(selected),when+dt)-model(c,torch.as_tensor(selected),when-dt))/(2*dt)
                actual=tensor((c['parts'][frames[:128]+1,selected]-c['parts'][frames[:128]-1,selected])/(2*dt))
                velocity_losses.append(((pred_velocity-actual)/(normal*2*torch.pi*freq)).square().mean())
                if j==0 and step%4==0:
                    nodes=rng.choice(len(mass),2,p=mass/mass.sum());t=tensor(c['times']);query=torch.as_tensor(np.tile(nodes,len(t)));prediction=model(c,query,t.repeat_interleave(2)).reshape(len(t),2,3,3);true=tensor(c['parts'][:,nodes]);delta=exact_harmonics(prediction,t,freq)-exact_harmonics(true,t,freq)
                    harmonic=(abs(delta)/norms[c['case_id']][None,:,None,None]).square().mean()
            data_loss=torch.stack(data_losses).mean();velocity=torch.stack(velocity_losses).mean();supervised=data_loss+.15*velocity+.2*harmonic
            c=chosen[-1];src=c['scene']['source'];t=float(src['delay_us']+rng.uniform(.15,.85)*src['cycles']/src['frequency_mhz']) if step%2==0 else float(rng.uniform(.05,c['times'][-1]-.05))
            interior,boundary,guard,_=physics_loss(model,c,t,scales,choose_targets(c,rng));physical=interior+boundary
            if step%50==0:
                params=list(model.parameters());gd=torch.autograd.grad(supervised,params,retain_graph=True,allow_unused=True);gp=torch.autograd.grad(physical,params,retain_graph=True,allow_unused=True)
                dn=torch.sqrt(sum(g.square().sum() for g in gd if g is not None));pn=torch.sqrt(sum(g.square().sum() for g in gp if g is not None))
                proposed=min(.002,max(1e-8,.1*float(dn)/max(float(pn),1e-15)));adaptive=.8*adaptive+.2*proposed
            weight=adaptive*min(1.,max(0.,(step-600)/1000));loss=supervised+weight*physical+10*guard
            if not torch.isfinite(loss):raise ValueError('Nonfinite retraining loss.')
            optimizer.zero_grad(set_to_none=True);loss.backward();gradient=torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
            if not torch.isfinite(gradient):raise ValueError('Nonfinite retraining gradient.')
            optimizer.step()
            for group in optimizer.param_groups:group['lr']=.001*(.12+.88*(1+math.cos(math.pi*step/args.steps))/2)
            if step==1 or step%200==0 or step==args.steps:
                val=validation(model,valid,designs,norms,scales,targets);score=val['relative_mse']+.0001*val['physics_mse'];selected=step>=200 and score<best
                if selected:best=score
                checkpoint={'model_state':model.state_dict(),'optimizer_state':optimizer.state_dict(),'step':step,'best_score':best if math.isfinite(best) else None,'width':args.width,'unit_scales':tensor(unit),'physical_scales':scales,'context_mean':mean,'context_std':std,'dataset_sha256':config['dataset_sha256'],'numpy_rng_state':rng.bit_generator.state,'torch_rng_state':torch.get_rng_state()};torch.save(checkpoint,out/'last.pt')
                if selected:torch.save(checkpoint,out/'best.pt')
                row={'step':step,'elapsed_s':time.monotonic()-started,'data':float(data_loss.detach()),'velocity':float(velocity.detach()),'harmonic':float(harmonic.detach()),'interior':float(interior.detach()),'boundary':float(boundary.detach()),'physics_weight':weight,'validation':val,'selected':selected}
                with (out/'history.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
                publish(step=step,validation=val);print(json.dumps({k:v for k,v in row.items() if k!='validation'}|{'validation_relative_mse':val['relative_mse'],'validation_physics_mse':val['physics_mse']}),flush=True)
        checkpoint=torch.load(out/'best.pt',map_location='cpu',weights_only=True);model.load_state_dict(checkpoint['model_state']);frozen=digest(out/'best.pt')
        copy=NormalizedWaveField(unit,mean,std,args.width);copy.load_state_dict(torch.load(out/'best.pt',map_location='cpu',weights_only=True)['model_state']);c=valid[0];ids=torch.arange(min(137,len(c['points'])));when=torch.linspace(0,14,len(ids),dtype=torch.float64)
        with torch.no_grad():torch.testing.assert_close(model(c,ids,when),copy(c,ids,when),rtol=0,atol=0)
        receipt={'checkpoint_sha256':frozen,'selected_step':checkpoint['step'],'frozen_at_utc':now(),'dataset_sha256':config['dataset_sha256'],'fresh_test_fields_loaded':False,'checkpoint_reload_exact':True,'accepted_for_solver_routing':False};atomic(out/'checkpoint-freeze.json',receipt)
        publish(status='trained_pending_fresh_tests',checkpoint_sha256=frozen,selected_step=checkpoint['step']);print(json.dumps(receipt),flush=True)
    except BaseException as error:publish(status='failed',error=str(error));raise


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dataset',type=Path,required=True);p.add_argument('--admission',type=Path,required=True);p.add_argument('--previous-tests',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--steps',type=int,default=12000);p.add_argument('--width',type=int,default=96);p.add_argument('--seed',type=int,default=2026102381);a=p.parse_args()
    if not 1000<=a.steps<=20000 or not 32<=a.width<=128:p.error('Use a bounded CPU retraining run.')
    run(a)

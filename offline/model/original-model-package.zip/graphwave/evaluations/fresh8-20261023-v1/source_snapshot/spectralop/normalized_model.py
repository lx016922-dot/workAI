"""Source-reflected, amplitude-normalized shared neural displacement field.

Homogeneous nonlinear increments are a leading quadratic approximation, not an
exact symmetry of finite-amplitude Murnaghan dynamics. Held-out gates still apply.
"""
import torch
from operator3d.propagation_model import PropagationSeparatedField,setup_features


def canonical_context(case):
    context=setup_features(case)['context'].clone()
    context[3]=0.  # Axial source face is the origin in reflected coordinates.
    context[8]=0.  # Delay enters only through elapsed query time.
    context[11]=1. # Amplitude is factored outside the neural decoder.
    direction=context[12:15].clone();direction/=torch.linalg.vector_norm(direction)
    if case['scene']['source']['face']=='xmax':direction[0]*=-1
    context[12:15]=direction
    return context


class NormalizedWaveField(PropagationSeparatedField):
    def __init__(self,scales,context_mean,context_std,width=96):
        super().__init__(scales,width)
        self.register_buffer('context_mean',torch.as_tensor(context_mean,dtype=torch.float64))
        self.register_buffer('context_std',torch.as_tensor(context_std,dtype=torch.float64))
        if self.context_mean.shape!=(28,) or self.context_std.shape!=(28,) or not torch.isfinite(self.context_mean).all() or not torch.isfinite(self.context_std).all() or not (self.context_std>0).all():
            raise ValueError('Invalid training-only context normalization.')

    def encode(self,case):
        f=setup_features(case);boundary=self.geometry(f['surfaces'])
        context=(canonical_context(case)-self.context_mean)/self.context_std
        pooled=torch.cat([(boundary*case['surface_weights'][:,None]).sum(0),boundary.max(0).values,context])
        return self.condition(pooled)

    def forward(self,case,indices,time):
        response=super().forward(case,indices,time);a=case['scene']['source']['amplitude_mpa']
        amplitude=response.new_tensor([a,a*a,a*a]);reflection=response.new_tensor([-1. if case['scene']['source']['face']=='xmax' else 1.,1.,1.])
        return response*amplitude[None,:,None]*reflection[None,None,:]


def exact_harmonics(values,times,frequency):
    """Hann, weighted demeaning, absolute record phase; shape time,...,2 complex."""
    weights=.5*(1-torch.cos(2*torch.pi*(times-times[0])/(times[-1]-times[0])))
    mean=torch.einsum('t,t...->...',weights,values)/weights.sum()
    phases=torch.exp(-2j*torch.pi*times[:,None]*frequency*times.new_tensor([1.,2.])[None,:])
    return 2*torch.einsum('th,t,t...->...h',phases,weights.to(phases.dtype),(values-mean).to(phases.dtype))/weights.sum()

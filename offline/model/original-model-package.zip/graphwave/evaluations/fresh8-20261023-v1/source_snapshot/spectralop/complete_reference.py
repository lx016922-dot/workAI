"""Finish the expensive hole reference using verified intermediate mesh reuse.

The original coordinator is paused externally while its in-flight fine-grid
campaign continues. This helper never selects or modifies neural weights.
"""
import argparse,json,os,shutil,subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from spectral3d.compare import spectral,compare,digest
from spectral3d.field_compare import compare_fields
from spectral3d.campaign import atomic,now


def run(a):
    root=a.references;manifest=json.loads((root/'manifest.json').read_text());frozen=digest(a.model/'best.pt')
    assert manifest['phase']=='running' and manifest['frozen_checkpoint_sha256']==frozen
    row=next(c for c in manifest['cases'] if c['case_id']=='neural-v2-test-hole');assert row['phase']=='refining'
    folder=root/row['case_id'];base=folder/'space/manifest.json';fine=folder/'refined-base/manifest.json'
    for path,h in [(base,1.4),(fine,1.)]:
        record=json.loads(path.read_text());assert record['degree']==4 and record['h_mm']==h and record['cases'][0]['scene']==row['scene']
    assert json.loads(base.read_text())['phase']=='completed'
    source=root/'source_snapshot/spectralop/complete_reference.py';shutil.copyfile(Path(__file__),source)
    plan={'schema':'workai.reference_mesh_reuse.v1','created_at_utc':now(),'frozen_checkpoint_sha256':frozen,'helper_source_sha256':digest(source),
          'reason':'Reuse completed p4/h1.4 as baseline and in-flight p4/h1 as spatial refinement; evaluate p5 and half-step independently. Avoid unnecessary finer-grid campaigns while keeping every original quality gate.',
          'base':str(base),'space':str(fine),'degree':{'p':5,'h_mm':1.4,'substeps':4},'time':{'p':4,'h_mm':1.4,'substeps':8},'threshold':.05,'neural_predictions_used':False}
    atomic(folder/'mesh-reuse-plan.json',plan)
    def solve(label,p,substeps):
        path=folder/label;cmd=[sys.executable,'-m','spectral3d.campaign','--campaign',str(root/'planned-inputs.json'),'--output',str(path),'--cases',row['case_id'],'--degree',str(p),'--h','1.4','--cfl',str(.3 if substeps==4 else .15),'--substeps',str(substeps),'--integrator','newmark']
        with (folder/(label+'.log')).open('x') as log:subprocess.run(cmd,cwd=root/'source_snapshot',env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=log,stderr=subprocess.STDOUT,timeout=1800,check=True)
        return path/'manifest.json'
    def await_fine():
        start=time.monotonic()
        while time.monotonic()-start<1800:
            status=json.loads(fine.read_text())['phase']
            if status=='completed':return fine
            if status=='failed':raise ValueError('In-flight fine-grid reference failed.')
            time.sleep(2)
        raise TimeoutError('In-flight fine-grid reference did not complete.')
    with ThreadPoolExecutor(max_workers=3) as pool:
        pending=[pool.submit(await_fine),pool.submit(solve,'reuse-degree',5,4),pool.submit(solve,'reuse-time',4,8)]
        space,degree,temporal=[f.result() for f in pending]
    paths={'base':base,'space':space,'degree':degree,'time':temporal};baseline=spectral(base)
    q={name:compare(baseline,spectral(paths[name])) for name in ['space','degree','time']};q['field']=compare_fields(base,space)
    q['levels']={k:{'manifest':str(v),'sha256':digest(v)} for k,v in paths.items()}
    q['guards_passed']=all(d['energy_balance_within_1_percent'] and d['max_strain']<=.001 and d['min_J']>0 for p in paths.values() for c in spectral(p).values() for d in c['diagnostics'])
    q['passed']=q['guards_passed'] and q['field']['all_checks_pass'] and all(q[k]['all_probe_checks_pass'] for k in ['space','degree','time'])
    quality=folder/'mesh-reuse-quality.json';atomic(quality,q)
    if not q['passed']:raise ValueError('Intermediate mesh reuse failed original quality gates; retain the result and resume original refinement.')
    assert digest(a.model/'best.pt')==frozen
    row['attempts'].append({'quality_path':str(quality),'sha256':digest(quality),'passed':True,'mesh_reuse_plan_sha256':digest(folder/'mesh-reuse-plan.json')})
    row.update(phase='completed',reference_checks_passed=True,base_manifest=str(base),base_manifest_sha256=digest(base),quality_path=str(quality),quality_sha256=digest(quality),levels=q['levels'])
    manifest['source_sha256']['spectralop/complete_reference.py']=digest(source)
    manifest['rule']+=' Hole completion subsequently reused the completed p4/h1.4 baseline and p4/h1 spatial check with separately computed p5/h1.4 and half-step checks, under unchanged thresholds. See mesh-reuse-plan.json.'
    manifest.update(phase='completed',all_reference_checks_passed=all(c.get('reference_checks_passed',False) for c in manifest['cases']),completed_at_utc=now(),updated_at_utc=now(),completion_workflow={'source_sha256':digest(source),'plan_sha256':digest(folder/'mesh-reuse-plan.json')})
    assert manifest['all_reference_checks_passed'];atomic(root/'manifest.json',manifest)
    print(json.dumps({'phase':'completed','all_reference_checks_passed':True,'checkpoint_sha256':frozen,'quality_path':str(quality)}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--references',type=Path,required=True);p.add_argument('--model',type=Path,required=True);run(p.parse_args())

"""Development-only ablation and physics-gradient audit; no fresh-test claim."""
import argparse,json,math,shutil,time
from pathlib import Path
import numpy as np
import torch
from .data import load_dataset,digest
from .physics import physics_loss,choose_targets,star,internal
from operator3d.physics import U0,T0,pulse
from operator3d.propagation_model import PropagationSeparatedField
from operator3d.train import atomic,now,design


def tensor(x):return torch.as_tensor(x,dtype=torch.float64)


def score(model,cases,designs,scales):
    rows=[]
    with torch.no_grad():
        for c in cases:
            ids,frames=designs[c['case_id']];truth=tensor(c['parts'][frames,ids]);pred=model(c,torch.as_tensor(ids),tensor(c['times'][frames]));error=(pred-truth).square().mean((0,2));norm=truth.square().mean((0,2))
            rows.append({'case_id':c['case_id'],'split':c['split'],'normalized_mse':float((error/scales.square()).mean()),'branch_relative_l2':torch.sqrt(error/norm).tolist()})
    return rows


def audit(model,cases,scales,rng):
    rows=[];parameters=list(model.parameters())
    for c in cases:
        if not c['case_id'].endswith('-0'):continue
        ids=rng.integers(len(c['points']),size=384);frames=rng.integers(1,len(c['times']),size=384);pred=model(c,torch.as_tensor(ids),tensor(c['times'][frames]));truth=tensor(c['parts'][frames,ids]);loss=((pred-truth)/scales[None,:,None]).square().mean()
        dg=torch.autograd.grad(loss,parameters,allow_unused=True);data=torch.cat([g.flatten() if g is not None else torch.zeros_like(p).flatten() for p,g in zip(parameters,dg)])
        targets=choose_targets(c,rng);t=c['times'][160];a,b,_,_=physics_loss(model,c,t,scales,targets);pg=torch.autograd.grad(a+b,parameters,allow_unused=True);physics=torch.cat([g.flatten() if g is not None else torch.zeros_like(p).flatten() for p,g in zip(parameters,pg)])
        reference=[];patch=star(c,targets);nodes=patch['ids'].numpy();target=patch['targets'];dt=c['times'][1]-c['times'][0]
        with torch.no_grad():
            for frame in [55,120,200]:
                values=tensor(c['parts'][frame-2:frame+3,nodes]);force,_,_=internal(values[2],c,patch);acc=(-values[4]+16*values[3]-30*values[2]+16*values[1]-values[0])[patch['at']]/(12*dt**2)
                external=c['load'][target]*pulse(tensor(c['times'][frame]),c['scene']['source']);ext=torch.stack([external,external*0,external*0],1)
                residual=acc+(force-ext)/(c['mass'][target,None,None]*(U0/T0**2));scale=scales[:,None]*(2*torch.pi*c['scene']['source']['frequency_mhz'])**2
                reference.append({'time_us':float(c['times'][frame]),'branch_rms':torch.sqrt((residual/scale).square().mean((0,2))).tolist()})
        rows.append({'case_id':c['case_id'],'data_gradient_norm':float(data.norm()),'physics_gradient_norm':float(physics.norm()),'weighted_physics_to_data_gradient_ratio':float(.002*physics.norm()/data.norm()),'gradient_cosine':float(torch.dot(data,physics)/(data.norm()*physics.norm())),'reference_five_point_acceleration_audit':reference})
    return rows


def run(args):
    out=args.output;out.mkdir(parents=True,exist_ok=False);start=time.monotonic();torch.set_num_threads(2);torch.manual_seed(2026102317);rng=np.random.default_rng(2026102317);repo=Path(__file__).resolve().parents[1];hashes={}
    for module in ['solid','spectral3d','operator3d','spectralop']:
        dest=out/'source_snapshot'/module;dest.mkdir(parents=True)
        for path in (repo/module).glob('*.py'):shutil.copyfile(path,dest/path.name);hashes[module+'/'+path.name]=digest(path)
    cases,scale,record=load_dataset(args.dataset,admission_path=args.admission);atomic(out/'dataset.json',record);scales=tensor(scale);train=[c for c in cases if c['split']=='train'];valid=[c for c in cases if c['split']=='validation'];drng=np.random.default_rng(2026102399);designs={c['case_id']:design(c,drng,nodes=192,frames=29) for c in cases}
    frozen=torch.load(args.previous/'best.pt',map_location='cpu',weights_only=True);previous=PropagationSeparatedField(scale,frozen['width']);previous.load_state_dict(frozen['model_state']);atomic(out/'previous-sampled-fields.json',score(previous,cases,designs,scales));atomic(out/'gradient-and-reference-audit.json',audit(previous,train,scales,drng))
    model=PropagationSeparatedField(scale,96);optimizer=torch.optim.Adam(model.parameters(),lr=.0015);best=float('inf');relative={c['case_id']:tensor(np.sqrt(np.einsum('tnkc,n->k',c['parts']**2,c['mass'].numpy()/c['mass'].numpy().sum())/(len(c['times'])*3))) for c in train}
    atomic(out/'config.json',{'schema':'workai.neural_diagnostic.v1','kind':'data_only_ablation','steps':args.steps,'relative_case_loss':args.relative_loss,'source_sha256':hashes,'previous_checkpoint_sha256':digest(args.previous/'best.pt'),'independent_test_fields_loaded':False,'solver_routing_enabled':False})
    for step in range(1,args.steps+1):
        losses=[]
        for index in rng.choice(len(train),2,replace=False):
            c=train[int(index)];mass=c['mass'].numpy();ids=rng.choice(len(mass),384,p=mass/mass.sum());frames=rng.integers(1,len(c['times']),384);pred=model(c,torch.as_tensor(ids),tensor(c['times'][frames]));truth=tensor(c['parts'][frames,ids]);normal=relative[c['case_id']] if args.relative_loss else scales;losses.append(((pred-truth)/normal[None,:,None]).square().mean())
        loss=torch.stack(losses).mean();optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10.);optimizer.step()
        for group in optimizer.param_groups:group['lr']=.0015*(.15+.85*(1+math.cos(math.pi*step/args.steps))/2)
        if step==1 or step%250==0:
            rows=score(model,cases,designs,scales);value=float(np.mean([r['normalized_mse'] for r in rows if r['split']=='validation']));selected=value<best
            if selected:best=value;torch.save({'model_state':model.state_dict(),'scales':scales,'width':96,'step':step},out/'best.pt')
            status={'step':step,'elapsed_s':time.monotonic()-start,'training_loss':float(loss.detach()),'validation_mse':value,'selected':selected,'cases':rows}
            with (out/'history.jsonl').open('a') as handle:handle.write(json.dumps(status)+'\n')
            atomic(out/'status.json',status);print(json.dumps({k:v for k,v in status.items() if k!='cases'}),flush=True)
    atomic(out/'completed.json',{'completed_at':now(),'steps':args.steps,'best_checkpoint_sha256':digest(out/'best.pt'),'test_fields_loaded':False,'accepted_for_solver_routing':False})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--dataset',type=Path,required=True);parser.add_argument('--admission',type=Path,required=True);parser.add_argument('--previous',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--steps',type=int,default=4000);parser.add_argument('--relative-loss',action='store_true');run(parser.parse_args())

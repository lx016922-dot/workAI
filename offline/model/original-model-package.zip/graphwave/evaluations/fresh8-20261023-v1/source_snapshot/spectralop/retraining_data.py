"""Reuse consumed tests as development data, with full reference/hash checks."""
import json
from pathlib import Path
import numpy as np
import torch
from .data import load_dataset,checked_reference,tensors,digest
from .normalized_model import canonical_context
from operator3d.campaign import geometry_identity
from operator3d.physics import U0
from spectral3d.field_compare import field
from spectral3d.mesh import interpolation


def reference_case(item,split):
    if not item['reference_checks_passed']:raise ValueError('Reference has not passed quality gates.')
    quality_path=Path(item['quality_path']);assert digest(quality_path)==item['quality_sha256'];q=json.loads(quality_path.read_text())
    assert q['passed'] and q['guards_passed'] and q['field']['all_checks_pass'] and all(q[k]['all_probe_checks_pass'] for k in ['space','degree','time'])
    base=Path(item['base_manifest']);assert digest(base)==item['base_manifest_sha256']
    for name,level in item['levels'].items():
        path=Path(level['manifest']);assert digest(path)==level['sha256']==q['levels'][name]['sha256']
        checked_reference(path)
    summary=checked_reference(base)[item['case_id']];manifest=json.loads(base.read_text());row=next(c for c in manifest['cases'] if c['case_id']==item['case_id'])
    assert row['scene']==item['scene']
    with np.load(base.parent/row['mesh_file'],allow_pickle=False) as archive:mesh=dict(archive)
    values=[field(base.parent,row,law) for law in ['linear','stvk','murnaghan']]
    parts=np.stack([values[0],values[1]-values[0],values[2]-values[1]],2)/U0
    assert np.isfinite(parts).all()
    case=tensors(item['scene'],mesh);case.update(case_id=item['case_id'],split=split,group=geometry_identity(item['scene']),parts=parts,times=summary['times'],receivers=[interpolation(mesh,r['point_mm']) for r in item['scene']['receivers']])
    evidence={'case_id':case['case_id'],'split':split,'geometry_group_sha256':case['group'],'base_manifest':str(base),'base_manifest_sha256':digest(base),'quality_sha256':item['quality_sha256'],'nodes':len(mesh['points']),'frames':len(parts)}
    return case,evidence


def load_development(dataset,admission,previous_tests):
    cases,_,record=load_dataset(dataset,splits=('train','validation','test'),admission_path=admission)
    # The original four test responses have already been evaluated and are now
    # explicitly development data. Keep the original validation geometries apart.
    for c in cases:
        if c['split']=='test':c['split']='train'
    for c in record['cases']:
        if c['split']=='test':c.update(split='train',previous_role='consumed_neural_test')
    extra=json.loads(previous_tests.read_text());assert extra['phase']=='completed' and extra['all_reference_checks_passed']
    for name,sha in extra['source_sha256'].items():assert digest(previous_tests.parent/'source_snapshot'/name)==sha
    for item in extra['cases']:
        c,e=reference_case(item,'train');e['previous_role']='consumed_learned_energy_test';cases.append(c);record['cases'].append(e)
    groups=[c['group'] for c in cases]
    if len(set(groups))!=len(groups):raise ValueError('Geometry overlap in retraining development sets.')
    train=[c for c in cases if c['split']=='train'];observed=[];unit=[]
    for c in train:
        mass=c['mass'].numpy();power=np.einsum('tnkc,n->k',c['parts']**2,mass/mass.sum())/(len(c['times'])*3)
        a=c['scene']['source']['amplitude_mpa'];factors=np.array([a,a*a,a*a]);observed.append(power);unit.append(power/factors**2)
    scales=np.maximum(np.sqrt(np.mean(observed,axis=0)),[1e-2,5e-7,5e-7]);unit_scales=np.maximum(np.sqrt(np.mean(unit,axis=0)),[1e-2,5e-7,5e-7])
    contexts=torch.stack([canonical_context(c) for c in train]);mean=contexts.mean(0);std=contexts.std(0,unbiased=False);std=torch.where(std<1e-6,torch.ones_like(std),std)
    record.update(schema='workai.neural_retraining_dataset.v1',split_counts={'train':len(train),'validation':len(cases)-len(train),'test':0},loaded_splits=['development_train','development_validation'],final_test_fields_loaded=False,
        previous_energy_tests_manifest_sha256=digest(previous_tests),old_test_cases_reclassified_as_development=True,branch_scales_in_100nm=scales.tolist(),unit_amplitude_branch_scales=unit_scales.tolist(),context_mean=mean.tolist(),context_std=std.tolist(),normalization_from_training_only=True)
    return cases,scales,unit_scales,mean,std,record


def case_rms(case):
    mass=case['mass'].numpy()
    power=np.einsum('tnkc,n->k',case['parts']**2,mass/mass.sum())/(len(case['times'])*3)
    return torch.as_tensor(np.maximum(np.sqrt(power),[1e-3,1e-6,1e-6]),dtype=torch.float64)

"""One frozen comparison against the previous network on new qualified cases."""
import argparse,json,shutil,time
from pathlib import Path
import numpy as np
import torch
from .normalized_model import NormalizedWaveField
from .retraining_data import reference_case
from .train import evaluate
from .data import digest
from operator3d.propagation_model import PropagationSeparatedField
from operator3d.train import atomic,now


def run(args):
    out=args.output;out.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);started=time.monotonic();freeze=json.loads((args.model/'checkpoint-freeze.json').read_text());frozen=digest(args.model/'best.pt');assert frozen==freeze['checkpoint_sha256']
    references=json.loads(args.references.read_text());assert references['phase']=='completed' and references['all_reference_checks_passed'] and references['frozen_checkpoint_sha256']==frozen
    assert digest(args.references.parent/'planned-inputs.json')==references['planned_inputs_sha256']
    for name,sha in references['source_sha256'].items():assert digest(args.references.parent/'source_snapshot'/name)==sha
    development=json.loads((args.model/'dataset.json').read_text());groups={c['geometry_group_sha256'] for c in development['cases']};cases=[];records=[]
    for item in references['cases']:
        c,e=reference_case(item,'test');assert c['group'] not in groups;groups.add(c['group']);cases.append(c);records.append(e)
    assert len(cases)==4;atomic(out/'test-dataset.json',{'reference_manifest_sha256':digest(args.references),'checkpoint_sha256':frozen,'checkpoint_freeze_sha256':digest(args.model/'checkpoint-freeze.json'),'cases':records,'test_used_for_selection':False})
    hashes={};repo=Path(__file__).resolve().parents[1]
    for module in ['spectralop','operator3d','spectral3d','solid']:
        dest=out/'source_snapshot'/module;dest.mkdir(parents=True)
        for p in (repo/module).glob('*.py'):shutil.copyfile(p,dest/p.name);hashes[module+'/'+p.name]=digest(p)
    atomic(out/'evaluation-source.json',hashes)
    status=json.loads((args.model/'status.json').read_text());status.update(status='evaluating',updated_at_utc=now());atomic(args.model/'status.json',status);atomic(args.model.parents[1]/'latest.json',status)
    saved=torch.load(args.model/'best.pt',map_location='cpu',weights_only=True);model=NormalizedWaveField(saved['unit_scales'],saved['context_mean'],saved['context_std'],saved['width']);model.load_state_dict(saved['model_state'])
    for name,network,scales in [('retrained',model,saved['physical_scales'])]:
        directory=out/name;directory.mkdir();metrics=evaluate(network,cases,scales,directory,2026102393);metrics.update(checkpoint_sha256=frozen,selected_step=saved['step'],test_used_for_checkpoint_selection=False);atomic(directory/'metrics.json',metrics)
    old=torch.load(args.previous/'best.pt',map_location='cpu',weights_only=True);baseline=PropagationSeparatedField(old['scales'],old['width']);baseline.load_state_dict(old['model_state']);baseline_sha=digest(args.previous/'best.pt');directory=out/'previous';directory.mkdir()
    previous=evaluate(baseline,cases,old['scales'],directory,2026102393);previous.update(checkpoint_sha256=baseline_sha,test_used_for_checkpoint_selection=False);atomic(directory/'metrics.json',previous)
    rows=[]
    for a,b in zip(metrics['cases'],previous['cases']):
        assert a['case_id']==b['case_id'];rows.append({'case_id':a['case_id'],'geometry':a['geometry']['kind'],
          'full_relative_l2':a['field_checks']['full_vector']['relative_l2'],'previous_full_relative_l2':b['field_checks']['full_vector']['relative_l2'],
          'material_relative_l2':a['field_checks']['material_vector']['relative_l2'],'previous_material_relative_l2':b['field_checks']['material_vector']['relative_l2'],
          'probe_checks_pass':a['probe_checks_pass'],'sampled_physics_pass':all(max(p['interior_rms'],p['boundary_rms'])<=.05 for p in a['sampled_physics'])})
    assert digest(args.model/'best.pt')==frozen and digest(args.previous/'best.pt')==baseline_sha
    report={'schema':'workai.neural_retraining_evaluation.v1','checkpoint_sha256':frozen,'previous_checkpoint_sha256':baseline_sha,'reference_manifest_sha256':digest(args.references),
        'metrics_sha256':digest(out/'retrained/metrics.json'),'previous_metrics_sha256':digest(out/'previous/metrics.json'),'new_training_steps':status['steps_total'],'selected_step':saved['step'],
        'split_counts':{'train':20,'validation':4,'test':4},'test_geometries_new_after_freeze':True,'test_used_for_checkpoint_selection':False,'cases':rows,'acceptance':metrics['acceptance'],
        'mean_full_relative_l2':float(np.mean([c['full_relative_l2'] for c in rows])),'mean_material_relative_l2':float(np.mean([c['material_relative_l2'] for c in rows])),
        'previous_mean_full_relative_l2':float(np.mean([c['previous_full_relative_l2'] for c in rows])),'previous_mean_material_relative_l2':float(np.mean([c['previous_material_relative_l2'] for c in rows])),
        'accepted_for_solver_routing':False,'completed_at_utc':now(),'evaluation_elapsed_s':time.monotonic()-started,
        'scope':'New four-family geometry test, exact reference thresholds retained. Physics evaluated at five sampled times/stars, not a full-domain proof. Quadratic amplitude structure is a leading-order approximation.'};atomic(out/'summary.json',report)
    status.update(status='completed_experimental',evaluation_path=str(out),evaluation_sha256=digest(out/'summary.json'),updated_at_utc=now());atomic(args.model/'status.json',status);atomic(args.model.parents[1]/'latest.json',status)
    print(json.dumps(report),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--references',type=Path,required=True);p.add_argument('--previous',type=Path,required=True);p.add_argument('--output',type=Path,required=True);run(p.parse_args())

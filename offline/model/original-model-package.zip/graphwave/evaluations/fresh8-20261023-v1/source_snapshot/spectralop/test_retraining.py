import copy,unittest
import numpy as np
import torch
from solid.schema import default_scene
from spectral3d.mesh import make_mesh
from spectralop.data import tensors
from spectralop.physics import physics_loss,choose_targets
from spectralop.normalized_model import NormalizedWaveField,exact_harmonics,canonical_context


class RetrainingConstraints(unittest.TestCase):
    def case(self):
        scene=default_scene('plate');scene['geometry'].update(length_mm=4.,width_mm=2.,thickness_mm=1.)
        scene['source'].update(face='xmin',center_mm=[0,1,.5],direction=[1,.1,-.05],amplitude_mpa=.8,delay_us=.2)
        scene['boundary']['fixed_face']='xmax'
        return tensors(scene,make_mesh(scene,3,2.))

    def model(self):return NormalizedWaveField([1.,1e-5,1e-4],np.zeros(28),np.ones(28),32)

    def test_exact_initial_fixed_and_leading_order_amplitude(self):
        case=self.case();model=self.model();ids=torch.arange(len(case['points']));t=torch.full((len(ids),),.2,dtype=torch.float64,requires_grad=True)
        response=model(case,ids,t);velocity=torch.autograd.grad(response.sum(),t)[0]
        self.assertEqual(int(torch.count_nonzero(response)),0);self.assertEqual(int(torch.count_nonzero(velocity)),0)
        when=torch.full_like(t,4.);a=model(case,ids,when);self.assertEqual(int(torch.count_nonzero(a[case['fixed']])),0)
        other=tensors(copy.deepcopy(case['scene']),case['mesh']);other['scene']['source']['amplitude_mpa']*=2
        b=model(other,ids,when);torch.testing.assert_close(b,a*torch.tensor([2.,4.,4.])[None,:,None],rtol=0,atol=0)
        other['scene']['source']['amplitude_mpa']=0;self.assertEqual(int(torch.count_nonzero(model(other,ids,when))),0)

    def test_reflection_covariance_and_delay_translation(self):
        case=self.case();scene=copy.deepcopy(case['scene']);scene['source'].update(face='xmax',center_mm=[4,1,.5],direction=[-1,.1,-.05]);scene['boundary']['fixed_face']='xmin'
        other=tensors(scene,case['mesh']);model=self.model();points=case['points'].numpy();target=points.copy();target[:,0]=points[:,0].max()-points[:,0]
        ids=np.array([np.argmin(np.linalg.norm(points-p,axis=1)) for p in target]);np.testing.assert_allclose(points[ids],target,atol=1e-15)
        torch.testing.assert_close(canonical_context(case),canonical_context(other),rtol=0,atol=1e-15)
        t=torch.full((len(ids),),4.,dtype=torch.float64);a=model(case,torch.arange(len(ids)),t);b=model(other,torch.as_tensor(ids),t)
        torch.testing.assert_close(b,a*torch.tensor([-1.,1.,1.])[None,None,:],rtol=1e-11,atol=1e-15)
        shifted=tensors(copy.deepcopy(case['scene']),case['mesh']);shifted['scene']['source']['delay_us']+=.7
        torch.testing.assert_close(model(shifted,torch.arange(len(ids)),t+.7),a,rtol=1e-12,atol=1e-15)

    def test_complex_harmonics_and_gradient(self):
        time=torch.linspace(0,10,1001,dtype=torch.float64);a=torch.tensor(2.3,dtype=torch.float64,requires_grad=True)
        signal=a*torch.cos(2*torch.pi*time+.4)+.7*torch.cos(4*torch.pi*time-.3)
        coefficients=exact_harmonics(signal[:,None],time,1)[0]
        torch.testing.assert_close(coefficients,torch.tensor([2.3*np.exp(.4j),.7*np.exp(-.3j)],dtype=torch.complex128),rtol=1e-12,atol=1e-12)
        derivative=torch.autograd.grad(abs(coefficients).sum(),a)[0];self.assertAlmostEqual(float(derivative),1.,places=12)

    def test_weak_physics_still_has_finite_trainable_gradients(self):
        case=self.case();model=self.model();a,b,g,guard=physics_loss(model,case,1.7,torch.tensor([1.,1e-5,1e-4]),choose_targets(case,np.random.default_rng(3)))
        (a+b+g).backward();gradients=[p.grad for p in model.parameters() if p.grad is not None]
        self.assertTrue(all(torch.isfinite(g).all() for g in gradients));self.assertTrue(any(torch.count_nonzero(g)>0 for g in gradients));self.assertGreater(float(guard['min_J'].detach()),0)


if __name__=='__main__':torch.set_num_threads(2);unittest.main()

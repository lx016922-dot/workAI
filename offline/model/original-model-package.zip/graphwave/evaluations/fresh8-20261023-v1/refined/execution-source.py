"""Stronger held-out check: neural field against independently refined fields.

Interpolation is solely for comparing different geometry grids. It does not
alter the stored neural field or feed any reference back into prediction.
"""
import argparse,gc,json,time,shutil
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix,save_npz
from spectral3d.mesh import interpolation
from spectral3d.field_compare import field,weighted
from spectral3d.compare import spectral,compare,complex_coefficient,digest
from .release import atomic


def run(args):
    if args.output.exists():
        if not args.resume_empty or any(args.output.iterdir()):raise ValueError('Refined check output already contains work.')
    else:args.output.mkdir(parents=True)
    shutil.copyfile(Path(__file__),args.output/'execution-source.py');rows=[]
    while len(rows)<8:
        references=json.loads(args.references.read_text());done={r['case_id'] for r in rows}
        available=[c for c in references['cases'] if c.get('reference_checks_passed') and c['case_id'] not in done and (args.evaluation/c['case_id']/'prediction.json').exists()]
        if not available:time.sleep(10);continue
        item=available[0]
        cid=item['case_id'];directory=args.evaluation/cid;receipt=json.loads((directory/'prediction.json').read_text());assert digest(directory/'fields.npz')==receipt['field_sha256']
        fine_path=Path(item['levels']['space']['manifest']);assert digest(fine_path)==item['levels']['space']['sha256'];manifest=json.loads(fine_path.read_text());entry=next(c for c in manifest['cases'] if c['case_id']==cid)
        with np.load(directory/'mesh.npz',allow_pickle=False) as saved:coarse=dict(saved)
        with np.load(fine_path.parent/entry['mesh_file'],allow_pickle=False) as saved:fine=dict(saved)
        r=[];c=[];values=[];extrapolated=0
        for i,point in enumerate(fine['points']*1000):
            try:ids,w=interpolation(coarse,point)
            except ValueError:
                if str(coarse.get('mapping_kind',''))!='isoparametric':raise
                from spectral3d.curved_mesh import interpolation as curved_interpolation
                ids,w=curved_interpolation(coarse,point,local_tolerance=.002);extrapolated+=1
            keep=abs(w)>1e-15;r.extend([i]*int(keep.sum()));c.extend(ids[keep]);values.extend(w[keep])
        transfer=csr_matrix((values,(r,c)),shape=(len(fine['points']),len(coarse['points'])));np.testing.assert_allclose(transfer@coarse['points'],fine['points'],rtol=1e-12,atol=1e-15)
        save_npz(args.output/(cid+'-comparison-transfer.npz'),transfer)
        with np.load(directory/'fields.npz',allow_pickle=False) as saved:p=[saved[k] for k in ['linear','stvk','murnaghan']];times=saved['times_us']
        t=[field(fine_path.parent,entry,law) for law in ['linear','stvk','murnaghan']];checks={}
        for name,a,b in [('full',p[2],t[2]),('material',p[2]-p[1],t[2]-t[1]),('geometric',p[1]-p[0],t[1]-t[0])]:
            mapped=np.empty_like(b)
            for start in range(0,len(a),16):
                chunk=a[start:start+16];mapped[start:start+len(chunk)]=(transfer@chunk.transpose(1,0,2).reshape(len(coarse['points']),-1)).reshape(len(fine['points']),len(chunk),3).transpose(1,0,2)
            checks[name+'_vector']=weighted(mapped,b,fine['mass'])
            for axis,label in enumerate('xyz'):checks[name+'_'+label]=weighted(mapped[:,:,axis:axis+1],b[:,:,axis:axis+1],fine['mass'])
            if name=='material':
                pc=complex_coefficient(times,mapped,2*item['scene']['source']['frequency_mhz']);tc=complex_coefficient(times,b,2*item['scene']['source']['frequency_mhz'])
                checks['material_2f_vector']=weighted(pc[None],tc[None],fine['mass'])
                for axis,label in enumerate('xyz'):checks['material_2f_'+label]=weighted(pc[None,:,axis:axis+1],tc[None,:,axis:axis+1],fine['mass'])
        with np.load(directory/'probes.npz',allow_pickle=False) as saved:controls=saved['controls']
        parts=np.stack([controls[:,:,0],controls[:,:,1]-controls[:,:,0],controls[:,:,2]-controls[:,:,1]],2)
        prediction={cid:{'scene':item['scene'],'times':times,'parts':parts,'diagnostics':receipt['diagnostics']}};trace=compare(prediction,spectral(fine_path))['cases'][0]
        row={'case_id':cid,'field_checks':checks,'probes':trace['probes'],'probe_checks_pass':trace['all_probe_checks_pass'],'passed':all(v['pass'] for v in checks.values()) and trace['all_probe_checks_pass'],
            'prediction_sha256':digest(directory/'prediction.json'),'fine_reference_sha256':digest(fine_path),'coarse_nodes':len(coarse['points']),'fine_nodes':len(fine['points']),
            'comparison_transfer_sha256':digest(args.output/(cid+'-comparison-transfer.npz')),'curved_boundary_extrapolated_comparison_nodes':extrapolated,'maximum_reference_coordinate_excess':.002,'prediction_modified':False}
        rows.append(row);atomic(args.output/(cid+'-metrics.json'),row);atomic(args.output/'partial.json',rows)
        print(json.dumps({'case_id':cid,'full_vs_refined':checks['full_vector']['relative_l2'],'material_vs_refined':checks['material_vector']['relative_l2'],'passed':row['passed'],'failed_fields':[k for k,v in checks.items() if not v['pass']]}),flush=True)
        del p,t,mapped,coarse,fine,transfer;gc.collect()
    while not (args.evaluation/'metrics.json').exists():time.sleep(10)
    base_metrics=json.loads((args.evaluation/'metrics.json').read_text());references=json.loads(args.references.read_text());assert references['all_reference_checks_passed']
    result={'schema':'workai.graphwave_refined_validation.v1','base_metrics_sha256':digest(args.evaluation/'metrics.json'),'weights_sha256':base_metrics['weights_sha256'],'execution_source_sha256':digest(args.output/'execution-source.py'),
            'threshold':.05,'reporting_floor_m':1e-13,'cases':rows,'all_gates_passed':len(rows)==8 and all(r['passed'] for r in rows),'correction_applied_to_prediction':False,
            'scope':'Neural predictions directly compared against independently refined reference fields and probes. Different curved surface discretizations use the existing bounded .002 reference-coordinate comparison tolerance. No reference was supplied to inference.'}
    atomic(args.output/'metrics.json',result)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--evaluation',type=Path,required=True);p.add_argument('--references',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--resume-empty',action='store_true');run(p.parse_args())
